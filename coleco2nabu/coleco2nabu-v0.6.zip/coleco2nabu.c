#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <stdint.h>
#include <ctype.h>

#define MAX_ROM_SIZE 0x8000 
#define STUB_SIZE 15

typedef struct {
    const char* desc;
    uint8_t search[3];
    uint8_t replace[3];
    size_t len;
} StandardPatch;

typedef struct {
    const char* desc;
    uint8_t search[2];
    uint8_t replace[2];
    uint16_t vector_offset;
    uint8_t vector_data[3];
} VectorPatch;

StandardPatch std_patches[] = {
    {"DI IM 1 -> NOPs", {0xF3, 0xED, 0x56}, {0x00, 0x00, 0x00}, 3},
    {"IM 1 DI -> NOPs", {0xED, 0x56, 0xF3}, {0x00, 0x00, 0x00}, 3},
    {"VDP Ctrl Write",  {0xD3, 0xBF},       {0xD3, 0xA1},       2},
    {"VDP Stat Read",   {0xDB, 0xBF},       {0xDB, 0xA1},       2},
    {"VDP Data Write",  {0xD3, 0xBE},       {0xD3, 0xA0},       2},
    {"VDP Data Read",   {0xDB, 0xBE},       {0xDB, 0xA0},       2},
    {"LD C, 0xBE init", {0x0E, 0xBE},       {0x0E, 0xA0},       2}, 
    {"LD C, 0xBF init", {0x0E, 0xBF},       {0x0E, 0xA1},       2}
};

VectorPatch vec_patches[] = {
    {"Sound (RST 0x30)",      {0xD3, 0xFF}, {0xF7, 0x00}, 0x001B, {0xC3, 0x0C, 0x21}},
    {"Sound Alt (RST 0x30)",  {0xD3, 0xE0}, {0xF7, 0x00}, 0x001B, {0xC3, 0x0C, 0x21}},
    {"Joy/KP 1 (RST 0x18)",   {0xDB, 0xFF}, {0xDF, 0x00}, 0x0012, {0xC3, 0x06, 0x21}},
    {"Joy/KP 2 (RST 0x20)",   {0xDB, 0xFC}, {0xE7, 0x00}, 0x0015, {0xC3, 0x09, 0x21}},
    {"Joy Switch (RST 0x28)", {0xD3, 0xC0}, {0xEF, 0x00}, 0x0018, {0xC3, 0x03, 0x21}},
    {"KP Switch (RST 0x10)",  {0xD3, 0x80}, {0xD7, 0x00}, 0x000F, {0xC3, 0x00, 0x21}}
};

uint32_t parse_hex(const char* s) {
    if (!s) return 0;
    while (*s && !isxdigit((unsigned char)*s)) s++;
    return (uint32_t)strtoul(s, NULL, 16);
}

uint16_t calculate_crc16(const uint8_t* data, size_t len) {
    uint16_t crc = 0xFFFF;
    for (size_t i = 0; i < len; i++) {
        crc ^= (uint16_t)data[i] << 8;
        for (uint8_t j = 0; j < 8; j++) {
            if (crc & 0x8000) crc = (crc << 1) ^ 0x1021;
            else crc <<= 1;
        }
    }
    return crc & 0xFFFF;
}

// Coleco CPU vectors -> cart jump slots (BIOS RST n / NMI jump through these).
static int rst_slot(int rst) {
    switch (rst) {
        case 0x08: return 0x0C; case 0x10: return 0x0F; case 0x18: return 0x12; case 0x20: return 0x15;
        case 0x28: return 0x18; case 0x30: return 0x1B; case 0x38: return 0x1E;
    }
    return -1;
}

static uint8_t rom_at(const uint8_t* rom, size_t n, size_t i) { return i < n ? rom[i] : 0; }

// Length of the Z80 instruction at rom[i].
static int z80_len(const uint8_t* rom, size_t n, size_t i) {
    uint8_t op = rom_at(rom, n, i);
    if (op == 0xCB) return 2;
    if (op == 0xED) return (rom_at(rom, n, i + 1) & 0xC7) == 0x43 ? 4 : 2;   // LD (nn),rr / LD rr,(nn)
    if (op == 0xDD || op == 0xFD) {
        uint8_t op2 = rom_at(rom, n, i + 1);
        if (op2 == 0xCB) return 4;
        if (op2 == 0xDD || op2 == 0xFD || op2 == 0xED) return 1;
        int disp = op2 == 0x34 || op2 == 0x35 || op2 == 0x36 ||
                   ((op2 & 0xC7) == 0x46 && op2 != 0x76) || (op2 >= 0x70 && op2 <= 0x77 && op2 != 0x76) ||
                   (op2 & 0xC7) == 0x86;
        return 1 + z80_len(rom, n, i + 1) + disp;
    }
    if ((op & 0xCF) == 0x01 || op == 0x22 || op == 0x2A || op == 0x32 || op == 0x3A ||
        (op & 0xC7) == 0xC2 || op == 0xC3 || (op & 0xC7) == 0xC4 || op == 0xCD) return 3;
    if ((op & 0xC7) == 0x06 || op == 0x10 || op == 0x18 || (op & 0xE7) == 0x20 ||
        (op & 0xC7) == 0xC6 || op == 0xD3 || op == 0xDB) return 2;
    return 1;
}

// Result of tracing the cart's code:
//   start    - 1 where a traced instruction starts
//   owner    - start offset of the traced instruction covering each byte, or -1
//   conflict - 1 where two paths decode the bytes differently (one is really data)
//   xstart/xconflict - the same, plus code reached only through jump variables (LD HL,nn /
//              LD (mm),HL where elsewhere the code does LD HL,(mm) and jumps to it). Less certain,
//              so only used to allow DI/IM 1 removal, never to block other patches.
typedef struct {
    size_t n;
    uint8_t *start, *conflict, *xstart, *xconflict;
    int32_t *owner, *xowner;
    int nmi_uses_ei, nmi_reads_iff;
} CodeMap;

typedef struct { uint32_t target; uint16_t var; } Store;
typedef struct {
    Store* stores; size_t nstores, capstores;
    uint8_t jumps[0x10000];                            // 1 = address used as a jump variable
} TraceVars;

typedef struct { int32_t* v; size_t len, cap; } Stack;
static void push(Stack* s, int32_t v) {
    if (s->len == s->cap) { s->cap = s->cap ? s->cap * 2 : 256; s->v = realloc(s->v, s->cap * sizeof *s->v); }
    s->v[s->len++] = v;
}

static void run_trace(const uint8_t* rom, size_t n, Stack* todo, uint8_t* start, int32_t* owner,
                      uint8_t* conflict, TraceVars* vars) {
    while (todo->len) {
        int32_t pc = todo->v[--todo->len];
        while (pc >= 0 && (size_t)pc < n && !start[pc]) {
            int len = z80_len(rom, n, pc);
            if ((size_t)pc + len > n) break;
            int clash = 0;
            for (int k = 0; k < len; k++) if (owner[pc + k] != -1) clash = 1;
            if (clash) {
                for (int k = 0; k < len; k++) {
                    int32_t o = owner[pc + k];
                    conflict[pc + k] = 1;
                    if (o != -1) for (int j = 0, ol = z80_len(rom, n, o); j < ol && (size_t)(o + j) < n; j++) conflict[o + j] = 1;
                }
                break;
            }
            start[pc] = 1;
            for (int k = 0; k < len; k++) owner[pc + k] = pc;
            uint8_t op = rom[pc];
            uint16_t nn = rom_at(rom, n, pc + 1) | (rom_at(rom, n, pc + 2) << 8);
            int32_t rel = pc + 0x8000 + 2 + (int8_t)rom_at(rom, n, pc + 1);
            int stop = 0;
            #define ADDR(a) do { if ((a) >= 0x8000 && (size_t)((a) - 0x8000) < n) push(todo, (a) - 0x8000); } while (0)
            if (op == 0xC3) { ADDR(nn); stop = 1; }
            else if ((op & 0xC7) == 0xC2 || op == 0xCD || (op & 0xC7) == 0xC4) ADDR(nn);
            else if (op == 0x18) { ADDR(rel); stop = 1; }
            else if (op == 0x10 || (op & 0xE7) == 0x20) ADDR(rel);
            else if ((op & 0xC7) == 0xC7) { if (op == 0xC7) stop = 1; else push(todo, rst_slot(op & 0x38)); }
            else if (op == 0xC9 || op == 0xE9) stop = 1;
            else if (op == 0xED && (rom_at(rom, n, pc + 1) == 0x45 || rom_at(rom, n, pc + 1) == 0x4D)) stop = 1;
            else if ((op == 0xDD || op == 0xFD) && rom_at(rom, n, pc + 1) == 0xE9) stop = 1;
            else if (op == 0x21 && rom_at(rom, n, pc + 3) == 0x22) {           // LD HL,nn / LD (mm),HL
                if (nn >= 0x8000 && (size_t)(nn - 0x8000) < n) {
                    if (vars->nstores == vars->capstores) {
                        vars->capstores = vars->capstores ? vars->capstores * 2 : 64;
                        vars->stores = realloc(vars->stores, vars->capstores * sizeof *vars->stores);
                    }
                    vars->stores[vars->nstores].target = nn - 0x8000;
                    vars->stores[vars->nstores].var = rom_at(rom, n, pc + 4) | (rom_at(rom, n, pc + 5) << 8);
                    vars->nstores++;
                }
            }
            else if (op == 0x2A) {                                              // LD HL,(mm) then jump to it
                size_t a = pc + 3;
                uint16_t b = rom_at(rom, n, a + 1) | (rom_at(rom, n, a + 2) << 8);
                uint8_t x = rom_at(rom, n, a), y = rom_at(rom, n, a + 1);
                if (x == 0xE9 || (x == 0xE3 && y == 0xC9) || (x == 0xE5 && y == 0xC9) ||
                    (x == 0xCD && b >= 0x8000 && (size_t)(b - 0x8000) < n && rom[b - 0x8000] == 0xE9)) vars->jumps[nn] = 1;
            }
            #undef ADDR
            if (stop) break;
            pc += len;
        }
    }
}

// True if the instruction op (op2 >= 0: two-byte op, op op2) can be reached from rom[i]
// (following branches and calls, not returns).
static int reaches_op(const uint8_t* rom, size_t n, size_t i, int op1, int op2) {
    uint8_t* seen = calloc(n, 1);
    Stack todo = {0};
    int budget = 4000, found = 0;
    push(&todo, (int32_t)i);
    #define PUSHA(a) do { if ((a) >= 0x8000 && (size_t)((a) - 0x8000) < n) push(&todo, (a) - 0x8000); } while (0)
    while (todo.len && budget > 0 && !found) {
        int32_t pc = todo.v[--todo.len];
        while (pc >= 0 && (size_t)pc < n && !seen[pc] && budget-- > 0) {
            seen[pc] = 1;
            uint8_t op = rom[pc];
            uint16_t nn = rom_at(rom, n, pc + 1) | (rom_at(rom, n, pc + 2) << 8);
            int32_t rel = pc + 0x8000 + 2 + (int8_t)rom_at(rom, n, pc + 1);
            if (op == op1 && (op2 < 0 || rom_at(rom, n, pc + 1) == op2)) { found = 1; break; }
            if (op == 0xC3) { PUSHA(nn); break; }
            if (op == 0x18) { PUSHA(rel); break; }
            if ((op & 0xC7) == 0xC2 || op == 0xCD || (op & 0xC7) == 0xC4) PUSHA(nn);
            else if (op == 0x10 || (op & 0xE7) == 0x20) PUSHA(rel);
            else if ((op & 0xC7) == 0xC7 && op != 0xC7) PUSHA(0x8000 + rst_slot(op & 0x38));
            if (op == 0xC9 || op == 0xE9 || op == 0xC7) break;
            if (op == 0xED && (rom_at(rom, n, pc + 1) == 0x45 || rom_at(rom, n, pc + 1) == 0x4D)) break;
            if ((op == 0xDD || op == 0xFD) && rom_at(rom, n, pc + 1) == 0xE9) break;
            pc += z80_len(rom, n, pc);
        }
    }
    #undef PUSHA
    free(todo.v); free(seen);
    return found;
}

// True if an instruction that uses C as a port (IN r,(C), OUT (C),r, INI/OUTI/INIR/OTIR...)
// starts at rom[i], after at most two DI/EI/NOPs. Unlike uses_c_as_port this needs no tracing, so
// it is kept this tight: such a sequence right after LD BC,nn is very unlikely in data. An RST whose
// cart slot jumps straight to such an instruction counts too (Zombie Near: LD BC,$80BE / RST $18,
// RST $18 = OUTI loop).
static int port_op_soon(const uint8_t* rom, size_t n, size_t i) {
    for (int k = 0; k < 3 && i + 1 < n; k++, i++) {
        uint8_t op = rom[i], op2 = rom[i + 1];
        if (op == 0xED && ((op2 & 0xC6) == 0x40 || op2 == 0xA2 || op2 == 0xA3 || op2 == 0xAA || op2 == 0xAB ||
                           op2 == 0xB2 || op2 == 0xB3 || op2 == 0xBA || op2 == 0xBB)) return 1;
        if ((op & 0xC7) == 0xC7 && op != 0xC7) {
            int slot = rst_slot(op & 0x38);
            if (slot < 0 || (size_t)slot + 2 >= n || rom[slot] != 0xC3) return 0;
            int t = (rom[slot + 1] | (rom[slot + 2] << 8)) - 0x8000;
            if (t < 0 || (size_t)t + 1 >= n || rom[t] != 0xED) return 0;
            op2 = rom[t + 1];
            return (op2 & 0xC6) == 0x40 || op2 == 0xA2 || op2 == 0xA3 || op2 == 0xAA || op2 == 0xAB ||
                   op2 == 0xB2 || op2 == 0xB3 || op2 == 0xBA || op2 == 0xBB;
        }
        if (op != 0xF3 && op != 0xFB && op != 0x00) return 0;
    }
    return 0;
}

// True if, following the code from rom[i], register C is used as an I/O port (IN r,(C), OUT (C),r,
// INI/OUTI/INIR/OTIR...) before anything changes it. Follows branches and calls.
static int uses_c_as_port(const uint8_t* rom, size_t n, size_t i) {
    uint8_t* seen = calloc(n, 1);
    Stack todo = {0};
    int budget = 2000, found = 0;
    push(&todo, (int32_t)i);
    #define PUSHA(a) do { if ((a) >= 0x8000 && (size_t)((a) - 0x8000) < n) push(&todo, (a) - 0x8000); } while (0)
    while (todo.len && budget > 0 && !found) {
        int32_t pc = todo.v[--todo.len];
        while (pc >= 0 && (size_t)pc < n && !seen[pc] && budget-- > 0) {
            seen[pc] = 1;
            uint8_t op = rom[pc], op2 = rom_at(rom, n, pc + 1);
            uint16_t nn = op2 | (rom_at(rom, n, pc + 2) << 8);
            int32_t rel = pc + 0x8000 + 2 + (int8_t)op2;
            if (op == 0xED) {
                if ((op2 & 0xC6) == 0x40 || op2 == 0xA2 || op2 == 0xA3 || op2 == 0xAA || op2 == 0xAB ||
                    op2 == 0xB2 || op2 == 0xB3 || op2 == 0xBA || op2 == 0xBB) { found = 1; break; }
                if (op2 == 0x4B) break;                                   // LD BC,(nn)
            }
            // anything that changes C ends this path
            if (op == 0x0E || op == 0x01 || op == 0xC1 || (op >= 0x48 && op <= 0x4F) || op == 0x0C || op == 0x0D ||
                op == 0x03 || op == 0x0B || op == 0xD9 || (op == 0xCB && (op2 & 7) == 1 && (op2 < 0x40 || op2 >= 0x80))) break;
            if (op == 0xC3) { PUSHA(nn); break; }
            if (op == 0x18) { PUSHA(rel); break; }
            if ((op & 0xC7) == 0xC2 || op == 0xCD || (op & 0xC7) == 0xC4) PUSHA(nn);
            else if (op == 0x10 || (op & 0xE7) == 0x20) PUSHA(rel);
            else if ((op & 0xC7) == 0xC7 && op != 0xC7) PUSHA(0x8000 + rst_slot(op & 0x38));
            if (op == 0xC9 || op == 0xE9 || op == 0xC7) break;
            if (op == 0xED && (op2 == 0x45 || op2 == 0x4D)) break;
            if ((op == 0xDD || op == 0xFD) && op2 == 0xE9) break;
            pc += z80_len(rom, n, pc);
        }
    }
    #undef PUSHA
    free(todo.v); free(seen);
    return found;
}

// True if disassembling from most of the 16 bytes before rom[i] lands on i (see trace_code).
static int lands_on(const uint8_t* rom, size_t n, size_t i) {
    int over = 0, land = 0;
    for (size_t s = i >= 16 ? i - 16 : 0; s < i; s++) {
        size_t pc = s;
        while (pc < i) pc += z80_len(rom, n, pc);
        if (pc == i) land++; else over++;
    }
    return land > over;
}

// Recursive-descent trace of cart code from the header entry points.
static CodeMap* trace_code(const uint8_t* rom, size_t n) {
    CodeMap* c = calloc(1, sizeof *c);
    c->n = n;
    c->start = calloc(n, 1); c->conflict = calloc(n, 1);
    c->owner = malloc(n * sizeof *c->owner);
    for (size_t i = 0; i < n; i++) c->owner[i] = -1;
    TraceVars* vars = calloc(1, sizeof *vars);
    Stack todo = {0};
    if (n >= 0x24 && ((rom[0] == 0xAA && rom[1] == 0x55) || (rom[0] == 0x55 && rom[1] == 0xAA))) {
        uint16_t entry = rom[0x0A] | (rom[0x0B] << 8);
        if (entry >= 0x8000 && (size_t)(entry - 0x8000) < n) push(&todo, entry - 0x8000);
        static const int slots[] = { 0x0C, 0x0F, 0x12, 0x15, 0x18, 0x1B, 0x1E, 0x21 };  // RSTs + NMI
        for (int k = 0; k < 8; k++) push(&todo, slots[k]);
    }
    run_trace(rom, n, &todo, c->start, c->owner, c->conflict, vars);

    c->xstart = malloc(n); memcpy(c->xstart, c->start, n);
    c->xconflict = malloc(n); memcpy(c->xconflict, c->conflict, n);
    c->xowner = malloc(n * sizeof *c->xowner); memcpy(c->xowner, c->owner, n * sizeof *c->owner);
    for (size_t used = 0;;) {
        size_t seeds = 0;
        for (size_t k = 0; k < vars->nstores; k++)
            if (vars->jumps[vars->stores[k].var]) { push(&todo, vars->stores[k].target); seeds++; }
        if (seeds == used) { todo.len = 0; break; }
        used = seeds;
        run_trace(rom, n, &todo, c->xstart, c->xowner, c->xconflict, vars);
    }
    // Routines called from 5 or more CALL nn in the ROM, traced or not: code the trace may not reach
    // when the game dispatches through tables (Venture: its VDP-access helper $98C9, 21 calls,
    // starts with a DI it never undoes). A CD byte counts as a call only where disassembling from
    // most of the 16 bytes before it lands on it (in data it is usually inside something else).
    // Only seeds xstart. Seeds go in order of first occurrence, like the web converter.
    uint16_t* calls = calloc(n, sizeof *calls);
    int32_t* order = malloc(n * sizeof *order);
    size_t norder = 0;
    for (size_t i = 0; i + 2 < n; i++)
        if (rom[i] == 0xCD && lands_on(rom, n, i)) {
            uint16_t a = rom[i + 1] | (rom[i + 2] << 8);
            if (a >= 0x8000 && (size_t)(a - 0x8000) < n) {
                if (!calls[a - 0x8000]) order[norder++] = a - 0x8000;
                if (calls[a - 0x8000] < 0xFFFF) calls[a - 0x8000]++;
            }
        }
    for (size_t k = 0; k < norder; k++) if (calls[order[k]] >= 5) push(&todo, order[k]);
    run_trace(rom, n, &todo, c->xstart, c->xowner, c->xconflict, vars);
    todo.len = 0;
    free(calls); free(order);
    c->nmi_uses_ei = n > 0x24 && reaches_op(rom, n, 0x21, 0xFB, -1);
    // LD A,I / LD A,R: the handler reads IFF2 (whether the game had interrupts enabled)
    c->nmi_reads_iff = n > 0x24 && (reaches_op(rom, n, 0x21, 0xED, 0x57) || reaches_op(rom, n, 0x21, 0xED, 0x5F));
    free(todo.v); free(vars->stores); free(vars);
    return c;
}

static void free_code(CodeMap* c) {
    free(c->start); free(c->conflict); free(c->xstart); free(c->xconflict);
    free(c->owner); free(c->xowner); free(c);
}

enum { ACCEPT_ANY, ACCEPT_IM1, ACCEPT_DI, ACCEPT_PORT, ACCEPT_LDC, ACCEPT_SOUND };

// ROM offsets (by ROM CRC16) that look like port I/O but are data the tracer can't tell apart, so they
// must not be patched.
typedef struct { uint16_t crc; int offsets[8]; } KnownData;
static const KnownData known_data[] = {
    {0xFCEB, {0x234D, 0x236D, -1}},   // Centipede (Atarisoft): "D3 C0" inside the shot sound's data, not OUT (C0),A
    {0x0393, {0x1B56, -1}},           // Blockem Sockem (2025-03-09): "D3 BF" inside LD HL,$BFD3 (score popup digits), untraced routine
    {0x5554, {0x7A23, -1}},           // Prince of Persia megacart (banks 15+14): "D3 C0" inside the climb animation's pointer table ($D334, $D4C0)
    {0x5BD8, {0x23C8, 0x4A16, 0x56CA, -1}},   // Strip Poker (poker.col): "D3 FF" inside the compressed pictures (title: $A034-$A3D3); its sound is all BIOS
    {0xC28A, {0x230D, 0x26EA, 0x2A36, 0x2A64, 0x2E07, -1}},   // Pac-Man Collection megacart (fixed bank): "D3 FF" / "DB FF" in tile tables
    {0x77C1, {0x0A05, -1}},           // Amy Chess: "D3 E0" inside the compressed title picture (read at $819C / $81B2)
    {0xEA20, {0x070F, 0x1A21, 0x2628, 0x2E87, 0x4BDF, -1}},   // Solar System (Amy Studio): "D3 E0" / "D3 FF" inside compressed pictures
};
// The same for a megacart's code banks converted at C000 (see megacart_banks): by the image's CRC16
// (fixed bank + bank NB-2) and the bank, offsets in the 32KB image (C000 = 4000h).
typedef struct { uint16_t crc; int bank; int offsets[8]; } KnownBankData;
static const KnownBankData known_bank_data[] = {
    {0xC28A, 0, {0x54FA, 0x5552, 0x5568, 0x5C84, 0x5CA8, -1}},           // Pac-Man Collection: maze layouts and tile tables
    {0xC28A, 1, {0x5637, 0x568F, 0x56A5, 0x5DC3, 0x5DE7, 0x6971, -1}},
    {0xC28A, 2, {0x5B0A, -1}},
};
static const int* cur_known = NULL;   // known data offsets for the ROM being converted (-1 terminated)
static const int* cur_bank_known = NULL;   // ... for the code bank being converted (megacarts)
static int known_fixed_only = 0;      // converting an extra bank: cur_known only counts in the fixed bank

static int is_known_data(size_t i) {
    if (!known_fixed_only || i < 0x4000)
        for (const int* p = cur_known; p && *p >= 0; p++) if ((size_t)*p == i) return 1;
    for (const int* p = cur_bank_known; p && *p >= 0; p++) if ((size_t)*p == i) return 1;
    return 0;
}

// ROM ranges (by ROM CRC16) that the BIOS sound routines write into. On a ColecoVision those writes
// are lost, and games rely on it; on the NABU the cart is RAM, so they would stick. See protect_rom.
typedef struct { uint16_t crc; int ranges[4][2]; } RomShadow;       // {offset, length}, length 0 = end
static const RomShadow rom_shadow[] = {
    // Globe Quiz / Where on Earth? (2026): its sound slots' data areas (SxDATA) are the code bytes at
    // $8453 and $845F ("LD DE,$7112 / JP"), so the BIOS keeps re-reading the song at $7112. The
    // BIOS's writes there corrupted that code and then the BIOS's own UPDATE_SOUND loop.
    {0x5110, {{0x0453, 0x16}, {0}}},
};

// True if the DI at rom[i] starts a short critical section: an EI follows within a few
// straight-line instructions (e.g. Blockem Sockem's DI / OUT (C),E / OUT (C),D / EI around a VDP
// address). On the NABU that DI keeps the loader's status read (which resets the VDP address
// latch) from landing between the two address bytes, so it stays. A DI that waits for the NMI
// reaches a jump or HALT first.
static int di_guards_section(const uint8_t* rom, size_t n, size_t i) {
    size_t pc = i + 1;
    for (int k = 0; k < 8 && pc < n; k++) {
        uint8_t op = rom[pc], op2 = pc + 1 < n ? rom[pc + 1] : 0;
        if (op == 0xFB) return 1;
        if (op == 0xF3 || op == 0x76 || op == 0xC3 || op == 0xC9 || op == 0xE9 || op == 0x18 || op == 0x10 ||
            (op & 0xE7) == 0x20 || (op & 0xC7) == 0xC2 || (op & 0xC7) == 0xC0 || (op & 0xC7) == 0xC7 ||
            (op == 0xED && (op2 == 0x45 || op2 == 0x4D)) || ((op == 0xDD || op == 0xFD) && op2 == 0xE9)) return 0;
        pc += z80_len(rom, n, pc);
    }
    return 0;
}

// Offsets of the patches made by the last find_and_replace() call (for RST dispatchers).
static int last_sites[1024];
static int last_nsites;

// code: trace_code() result (optional). Matches that start inside a traced instruction are
// skipped. accept: ACCEPT_IM1 / ACCEPT_DI only patch traced code (and skip silently).
int find_and_replace(uint8_t* data, size_t size, const uint8_t* search, const uint8_t* replace, size_t len, const char* desc,
                     const CodeMap* code, int accept) {
    last_nsites = 0;
    int count = 0;
    for (size_t i = 0; i + len <= size; i++) {
        if (memcmp(&data[i], search, len) != 0) continue;
        if (code) {
            if (is_known_data(i)) { printf("\n    [0x%04X] %s skipped (known data)", (uint32_t)i, desc); continue; }
            int32_t own = code->owner[i];
            if (own != -1 && (size_t)own != i && !code->conflict[i]) {
                if (accept == ACCEPT_ANY) printf("\n    [0x%04X] %s skipped (inside instruction at 0x%04X)", (uint32_t)i, desc, (uint32_t)own);
                continue;
            }
            if (accept == ACCEPT_LDC) {
                // 0E BE / 0E BF also turn up in data (e.g. Gyruss's pointer table): patch traced code,
                // a "LD C,port / RET" helper, or where C is visibly used as a port
                int traced = code->xstart[i] && !code->xconflict[i];
                if (!traced && !(i + 2 < size && data[i + 2] == 0xC9) && !uses_c_as_port(data, size, i + 2)) {
                    printf("\n    [0x%04X] %s skipped (looks like data)", (uint32_t)i, desc);
                    continue;
                }
            }
            else if (accept == ACCEPT_PORT) {
                // both forms are 3 bytes; code the tracer missed counts when a C-port instruction
                // follows right away (GhostBlaster: LD BC,$10BE / DI / INIR in an untraced routine)
                int traced = code->xstart[i] && !code->xconflict[i];
                if (!(traced && uses_c_as_port(data, size, i + 3)) && !port_op_soon(data, size, i + 3)) continue;
            }
            else if (accept == ACCEPT_SOUND) {
                int traced = code->xstart[i] && !code->xconflict[i];
                if (!traced && !(i >= 2 && (data[i - 2] == 0x3E || data[i - 2] == 0xF6) && data[i - 1] >= 0x80 &&
                                 lands_on(data, size, i))) continue;
            }
            else if (accept != ACCEPT_ANY && (!code->xstart[i] || code->xconflict[i])) continue;
            if (accept == ACCEPT_DI && (code->nmi_uses_ei || di_guards_section(data, size, i))) continue;
        }
        printf("\n    [0x%04X] %s", (uint32_t)i, desc);
        memcpy(&data[i], replace, len);
        if (last_nsites < 1024) last_sites[last_nsites++] = (int)i;
        count++;
    }
    return count;
}

// The Coleco VDP interrupt is an NMI, which DI and IM cannot block or redirect. On the NABU it is a
// maskable IM 2 interrupt, so a cart's own IM 1, or a DI (Coleco games often DI and then wait for
// the NMI), stops vblank (and keyboard) handling. Carts whose NMI handler does EI were written for
// maskable interrupts (MSX ports) and use DI/EI deliberately, so their DIs stay. Single-byte DI
// can't be matched blindly without hitting data, so these only apply to traced code.
static const uint8_t im1_op[2] = {0xED, 0x56}, di_op[1] = {0xF3}, nops[2] = {0x00, 0x00};

// The loader stub's info block (loader/loader.z80), the 17 bytes before the ROM image: "C2NI",
// version 2, then its own runtime address, the free space for per-ROM code (next .. end), the
// loader's saved VDP status byte, its options byte and its IN A,(C) replacement.
// option_bits: loader options for this ROM, set in the stub copy by process_file.
#define STUB_INFO_LEN 17
#define LOADER_OPT_SWAP_PORTS 0x02      // loader_options bits (loader/interrupts.z80)

// The loader's control map (loader/interrupts.z80): "C2KEYMP1", then a target for each ordinary key
// ($00-$7F), each special key (code - $E0, 16) and the joystick's left, down, right, up and fire.
// Targets: $00-$03 up/right/down/left, $04 left button, $05 right button, $10-$1B keypad 0-9 * #,
// +$20 the other controller, $FE swap sides, $FF nothing.
#define KEYMAP_ASC 8
#define KEYMAP_SPC (8 + 128)
#define KEYMAP_JOY (8 + 128 + 16)
static int find_keymap(const uint8_t* stub, size_t len) {
    for (size_t i = 0; i + KEYMAP_JOY + 5 <= len; i++) if (!memcmp(&stub[i], "C2KEYMP1", 8)) return (int)i;
    return -1;
}

// -upbutton2: joystick up and the up arrow press the right button; -swapfire: the left and right
// buttons trade places everywhere in the map (fire = right button, so up = left with both).
static void keymap_options(uint8_t* stub, size_t len, int swapfire, int upbutton2) {
    if (!swapfire && !upbutton2) return;
    int k = find_keymap(stub, len);
    if (k < 0) { printf("\n  WARNING: no control map in the loader stub: -swapfire / -upbutton2 ignored"); return; }
    if (upbutton2) {
        stub[k + KEYMAP_JOY + 3] = 0x05;
        stub[k + KEYMAP_SPC + 2] = 0x05;
        printf("\n  Up = button 2 (%s Coleco button)", swapfire ? "left" : "right");
    }
    if (swapfire) {
        for (int i = k + KEYMAP_ASC; i < k + KEYMAP_JOY + 5; i++)
            if (stub[i] < 0x40 && ((stub[i] & 0x1F) == 0x04 || (stub[i] & 0x1F) == 0x05)) stub[i] ^= 0x01;
        printf("\n  Fire buttons swapped: joystick fire = right button");
    }
}
typedef struct { uint8_t* stub; int info_off, self, next, end, saved, options, read_port_c, option_bits, i_shadow, i_tmp; } Gap;

static int stub_info(Gap* g, uint8_t* stub, size_t stub_off) {
    int o = (int)stub_off - STUB_INFO_LEN;
    if (o < 0 || memcmp(&stub[o], "C2NI", 4) || stub[o + 4] != 2) return 0;
    #define W(k) (stub[o + (k)] | (stub[o + (k) + 1] << 8))
    g->stub = stub; g->info_off = o; g->self = W(5);
    g->next = W(7); g->end = W(9); g->saved = W(11); g->options = W(13); g->read_port_c = W(15);
    g->option_bits = 0; g->i_shadow = g->i_tmp = -1;
    #undef W
    return 1;
}

// File offset in the stub of a loader runtime address.
static int gap_off(const Gap* g, int addr) { return addr - g->self + g->info_off; }

// RST dispatcher for a cart vector slot that the game uses itself: RSTs from the converter's patch
// sites (return address = site + 1) go to the loader routine, all others to the game's own target.
// Keeps AF and HL. Returns its length.
static int build_dispatcher(uint8_t* c, int addr, const int* sites, int nsites, int handler, int original) {
    int n = 0, fix[1024], nfix = 0;
    c[n++] = 0xE3; c[n++] = 0xF5;                               // EX (SP),HL / PUSH AF ; HL = return address
    for (int k = 0; k < nsites; k++) {
        int ret = 0x8000 + sites[k] + 1;
        c[n++] = 0x7D; c[n++] = 0xFE; c[n++] = ret & 0xFF; c[n++] = 0x20; c[n++] = 0x06;   // LD A,L / CP lo / JR NZ,next
        c[n++] = 0x7C; c[n++] = 0xFE; c[n++] = ret >> 8; c[n++] = 0xCA; fix[nfix++] = n; c[n++] = 0; c[n++] = 0;  // LD A,H / CP hi / JP Z,ours
    }
    c[n++] = 0xF1; c[n++] = 0xE3; c[n++] = 0xC3; c[n++] = original & 0xFF; c[n++] = original >> 8;  // POP AF / EX (SP),HL / JP original
    int ours = addr + n;
    for (int k = 0; k < nfix; k++) { c[fix[k]] = ours & 0xFF; c[fix[k] + 1] = ours >> 8; }
    c[n++] = 0xF1; c[n++] = 0xE3; c[n++] = 0xC3; c[n++] = handler & 0xFF; c[n++] = handler >> 8;   // ours: POP AF / EX (SP),HL / JP handler
    return n;
}

typedef struct { int slot; uint8_t data[3]; const char* desc; int sites[1024]; int nsites; } Vector;

// Point cart vector slots at the loader's routines. If the game's own slot already holds a JP (it
// uses that RST itself, e.g. Gyruss's RST $18 = write VDP register), install a dispatcher instead
// of overwriting it.
static void install_vectors(uint8_t* rom, size_t rom_len, const uint8_t* orig, Vector* v, int nv, Gap* gap) {
    static uint8_t buf[16 + 11 * 1024];
    for (int i = 0; i < nv; i++) {
        int slot = v[i].slot;
        if (rom_len <= (size_t)slot + 3) continue;
        int target = orig[slot + 1] | (orig[slot + 2] << 8);
        if (orig[slot] == 0xC3 && target != 0 && gap && gap->next) {
            int handler = v[i].data[1] | (v[i].data[2] << 8);
            int len = build_dispatcher(buf, gap->next, v[i].sites, v[i].nsites, handler, target);
            if (gap->next + len > gap->end) { printf("\n    [0x%04X] Vector Table: %s - no room for a dispatcher!", slot, v[i].desc); continue; }
            memcpy(&gap->stub[gap_off(gap, gap->next)], buf, len);
            printf("\n    [0x%04X] Vector Table: %s (game uses this RST too: dispatcher at 0x%04X)", slot, v[i].desc, gap->next);
            rom[slot] = 0xC3; rom[slot + 1] = gap->next & 0xFF; rom[slot + 2] = gap->next >> 8;
            gap->next += len;
        } else {
            printf("\n    [0x%04X] Vector Table: %s", slot, v[i].desc);
            memcpy(&rom[slot], v[i].data, 3);
        }
    }
}

// Sound written with C = port: OUT (C),r / OUTI / OUTD / OTIR / OTDR after a traced LD C,n with n a
// sound port ($E0-$FF) (Wonder Boy mutes the chip with LD C,$F0 / OUT (C),L / OUT (C),H and OTIR).
// Follows the code from each such LD C,n until C changes. Marks found[offset] = second opcode byte.
static int is_out_c_op(uint8_t op2) {
    return op2 == 0x41 || op2 == 0x49 || op2 == 0x51 || op2 == 0x59 || op2 == 0x61 || op2 == 0x69 || op2 == 0x79 ||
           op2 == 0xA3 || op2 == 0xAB || op2 == 0xB3 || op2 == 0xBB;
}

static void sound_via_c(const uint8_t* rom, size_t n, const CodeMap* code, uint8_t* found) {
    uint8_t* seen = malloc(n);
    Stack todo = {0};
    #define PUSHA(a) do { if ((a) >= 0x8000 && (size_t)((a) - 0x8000) < n) push(&todo, (a) - 0x8000); } while (0)
    for (size_t i = 0; i + 1 < n; i++) {
        // LD C,n or LD BC,nn with n / the low byte a sound port (Aztec Challenge: LD BC,$03FF, B counts the channels)
        if ((rom[i] != 0x0E && rom[i] != 0x01) || rom[i + 1] < 0xE0 || !code->xstart[i] || code->xconflict[i]) continue;
        memset(seen, 0, n);
        todo.len = 0;
        push(&todo, (int32_t)i + (rom[i] == 0x01 ? 3 : 2));
        int budget = 2000;
        while (todo.len && budget > 0) {
            int32_t pc = todo.v[--todo.len];
            while (pc >= 0 && (size_t)pc < n && !seen[pc] && budget-- > 0) {
                seen[pc] = 1;
                uint8_t op = rom[pc], op2 = rom_at(rom, n, pc + 1);
                uint16_t nn = op2 | (rom_at(rom, n, pc + 2) << 8);
                int32_t rel = pc + 0x8000 + 2 + (int8_t)op2;
                if (op == 0xED && is_out_c_op(op2)) found[pc] = op2;
                if (op == 0xED && op2 == 0x4B) break;                         // LD BC,(nn)
                // anything that changes C ends this path
                if (op == 0x0E || op == 0x01 || op == 0xC1 || (op >= 0x48 && op <= 0x4F) || op == 0x0C || op == 0x0D ||
                    op == 0x03 || op == 0x0B || op == 0xD9 || (op == 0xCB && (op2 & 7) == 1 && (op2 < 0x40 || op2 >= 0x80))) break;
                if (op == 0xC3) { PUSHA(nn); break; }
                if (op == 0x18) { PUSHA(rel); break; }
                if ((op & 0xC7) == 0xC2 || op == 0xCD || (op & 0xC7) == 0xC4) PUSHA(nn);
                else if (op == 0x10 || (op & 0xE7) == 0x20) PUSHA(rel);
                if (op == 0xC9 || op == 0xE9 || (op & 0xC7) == 0xC7) break;
                if (op == 0xED && (op2 == 0x45 || op2 == 0x4D)) break;
                if ((op == 0xDD || op == 0xFD) && op2 == 0xE9) break;
                pc += z80_len(rom, n, pc);
            }
        }
    }
    #undef PUSHA
    free(todo.v); free(seen);
}

// The converter's RST $30 handler when some sites write sound with C = port. Those sites are
// RST $30 / op2 (the instruction's second byte, never 0); plain sound sites are RST $30 / NOP. It
// reads the byte after the RST: 0 goes to the loader's sound routine; otherwise it returns past the
// byte, through the thunk for op2 (ops[k] -> thunks[k]). Keeps all registers. Returns its length.
static int sound_c_handler(uint8_t* c, int addr, const uint8_t* ops, const int* thunks, int nops, int sound) {
    int n = 0, tail0 = addr + 12 + 5 * nops;
    const uint8_t head[] = {0xE3, 0xF5, 0x7E, 0xB7, 0x28, (uint8_t)(5 * nops + 1), 0x23};   // EX (SP),HL / PUSH AF / LD A,(HL) / OR A / JR Z,plain / INC HL
    memcpy(c, head, sizeof head); n = sizeof head;
    for (int k = 0; k < nops; k++) {                                       // CP op2 / JP Z,tail k
        int t = tail0 + 5 * k;
        c[n++] = 0xFE; c[n++] = ops[k]; c[n++] = 0xCA; c[n++] = t & 0xFF; c[n++] = t >> 8;
    }
    c[n++] = 0xF1; c[n++] = 0xE3; c[n++] = 0xC3; c[n++] = sound & 0xFF; c[n++] = sound >> 8;       // plain: POP AF / EX (SP),HL / JP sound
    for (int k = 0; k < nops; k++) {                                       // tail k: POP AF / EX (SP),HL / JP thunk k
        c[n++] = 0xF1; c[n++] = 0xE3; c[n++] = 0xC3; c[n++] = thunks[k] & 0xFF; c[n++] = thunks[k] >> 8;
    }
    return n;
}

// Replacement for OUT (C),r / OUTI / OUTD / OTIR / OTDR (op2), reached through sound_c_handler: C = $E0-$FF goes to
// the loader's sound routine (keeps all registers), any other port is really written (a routine
// shared with the VDP). Registers and the B/HL/Z results as the real instruction. Returns its length.
static int sound_c_thunk(uint8_t* c, uint8_t op2, int sound) {
    int n = 0;
    c[n++] = 0xF5; c[n++] = 0x79; c[n++] = 0xFE; c[n++] = 0xE0; c[n++] = 0x38; c[n++] = 0;   // PUSH AF / LD A,C / CP $E0 / JR C,real
    if (op2 < 0xA0) {                                                      // OUT (C),r
        int r = (op2 >> 3) & 7;
        c[n++] = 0xF1; c[n++] = 0xF5;                                      // POP AF / PUSH AF
        if (r != 7) c[n++] = 0x78 | r;                                     // LD A,r
        c[n++] = 0xCD; c[n++] = sound & 0xFF; c[n++] = sound >> 8; c[n++] = 0xF1; c[n++] = 0xC9;   // CALL sound / POP AF / RET
    } else {                                                               // OUTI / OUTD / OTIR / OTDR
        int loop = n;
        c[n++] = 0x7E; c[n++] = 0xCD; c[n++] = sound & 0xFF; c[n++] = sound >> 8;   // loop: LD A,(HL) / CALL sound
        c[n++] = op2 & 0x08 ? 0x2B : 0x23; c[n++] = 0x05;                  // INC HL or DEC HL / DEC B
        if (op2 & 0x10) { c[n] = 0x20; c[n + 1] = (uint8_t)(loop - (n + 2)); n += 2; }   // JR NZ,loop
        c[n++] = 0xF1; c[n++] = 0x04; c[n++] = 0x05; c[n++] = 0xC9;        // POP AF / INC B / DEC B (Z = B is 0) / RET
    }
    c[5] = (uint8_t)(n - 6);
    c[n++] = 0xF1; c[n++] = 0xED; c[n++] = op2; c[n++] = 0xC9;             // real: POP AF / the instruction / RET
    return n;
}

// An NMI handler that does EI (MSX-style) re-enters itself on the NABU: the loader calls it before
// reading the VDP status, so the level-triggered interrupt is still pending when the handler's EI
// runs, and the game's frame timers run several times too fast (Fall Guy). Point the cart's NMI
// slot at a wrapper that reads the status first (clearing the interrupt), adds the bits to the
// loader's saved status for READ_REGISTER, and jumps to the game's handler with the stack and
// registers as they were.
// A handler that reads IFF2 with LD A,I (Team Pixelboy's Wonder Boy: defer the frame if the game
// had interrupts disabled) always sees "disabled" on the NABU, where taking the maskable interrupt
// clears IFF2, and never runs its frame. For those the wrapper also does EI before the jump (the
// interrupt was taken, so the game had interrupts enabled; the VDP interrupt is already cleared).
static void wrap_nmi(uint8_t* rom, size_t rom_len, Gap* gap, int reads_iff) {
    if (!gap || !gap->saved || rom_len < 0x24 || rom[0x21] != 0xC3) return;
    int target = rom[0x22] | (rom[0x23] << 8), s = gap->saved, n = 0;
    uint8_t c[16];
    const uint8_t head[] = {0xF5, 0xE5, 0xDB, 0xA1, 0x21, s & 0xFF, s >> 8, 0xB6, 0x77, 0xE1, 0xF1};   // PUSH AF / PUSH HL / IN A,($A1) / LD HL,saved / OR (HL) / LD (HL),A / POP HL / POP AF
    memcpy(c, head, sizeof head); n = sizeof head;
    if (reads_iff) c[n++] = 0xFB;                                           // EI
    c[n++] = 0xC3; c[n++] = target & 0xFF; c[n++] = target >> 8;            // JP handler
    if (gap->next + n > gap->end) { printf("\n    [0x0021] NMI wrapper: no room!"); return; }
    memcpy(&gap->stub[gap_off(gap, gap->next)], c, n);
    printf("\n    [0x0021] NMI handler %s: wrapper at 0x%04X clears the VDP interrupt first%s",
           reads_iff ? "reads IFF2" : "does EI", gap->next, reads_iff ? " and enables interrupts" : "");
    rom[0x22] = gap->next & 0xFF; rom[0x23] = gap->next >> 8;
    gap->next += n;
}

// Keep the ROM ranges of a rom_shadow entry read-only in effect: a routine in the free space copies
// their original bytes back, and traced CALLs to the BIOS sound entry points (PLAY_SONGS, SOUND_INIT,
// PLAY_IT, SOUND_MAN) go through wrappers that restore before and after the call.
static void protect_rom(uint8_t* rom, size_t rom_len, const uint8_t* orig, const CodeMap* code, Gap* gap, uint16_t crc) {
    const RomShadow* e = NULL;
    for (size_t k = 0; k < sizeof rom_shadow / sizeof rom_shadow[0]; k++) if (rom_shadow[k].crc == crc) e = &rom_shadow[k];
    if (!e || !gap || !gap->next) return;
    static const int targets[] = {0x1F61, 0x1FEE, 0x1FF1, 0x1FF4};
    uint8_t c[1024];
    int n = 0, nr = 0, fix[4], restore = gap->next;
    c[n++] = 0xF5; c[n++] = 0xC5; c[n++] = 0xD5; c[n++] = 0xE5;           // PUSH AF / BC / DE / HL
    for (; nr < 4 && e->ranges[nr][1]; nr++) {
        int dst = 0x8000 + e->ranges[nr][0], len = e->ranges[nr][1];
        c[n++] = 0x21; fix[nr] = n; n += 2;                                  // LD HL,copy
        c[n++] = 0x11; c[n++] = dst & 0xFF; c[n++] = dst >> 8;               // LD DE,range
        c[n++] = 0x01; c[n++] = len & 0xFF; c[n++] = len >> 8;               // LD BC,length
        c[n++] = 0xED; c[n++] = 0xB0;                                        // LDIR
    }
    c[n++] = 0xE1; c[n++] = 0xD1; c[n++] = 0xC1; c[n++] = 0xF1; c[n++] = 0xC9;   // POP HL / DE / BC / AF / RET
    for (int r = 0; r < nr; r++) {                                           // the original bytes
        int a = restore + n;
        c[fix[r]] = a & 0xFF; c[fix[r] + 1] = a >> 8;
        memcpy(&c[n], &orig[e->ranges[r][0]], e->ranges[r][1]); n += e->ranges[r][1];
    }
    #define SOUND_CALL(i, t) (rom[i] == 0xCD && (rom[(i) + 1] | rom[(i) + 2] << 8) == (t) && code->xstart[i] && !code->xconflict[i])
    int used[4] = {0}, nw = 0;
    for (int t = 0; t < 4; t++)
        for (size_t i = 0; i + 2 < rom_len; i++) if (SOUND_CALL(i, targets[t])) used[t] = 1;
    for (int t = 0; t < 4; t++) nw += used[t];
    if (gap->next + n + 9 * nw > gap->end) { printf("\n    ROM write protection: no room!"); return; }
    printf("\n    ROM write protection: restore routine at 0x%04X", restore);
    for (int t = 0; t < 4; t++) {
        if (!used[t]) continue;
        int w = restore + n;
        for (size_t i = 0; i + 2 < rom_len; i++)
            if (SOUND_CALL(i, targets[t])) {
                printf("\n    [0x%04X] CALL $%04X -> wrapper at 0x%04X", (uint32_t)i, targets[t], w);
                rom[i + 1] = w & 0xFF; rom[i + 2] = w >> 8;
            }
        c[n++] = 0xCD; c[n++] = restore & 0xFF; c[n++] = restore >> 8;      // CALL restore
        c[n++] = 0xCD; c[n++] = targets[t] & 0xFF; c[n++] = targets[t] >> 8;   // CALL the BIOS
        c[n++] = 0xC3; c[n++] = restore & 0xFF; c[n++] = restore >> 8;      // JP restore
    }
    #undef SOUND_CALL
    memcpy(&gap->stub[gap_off(gap, gap->next)], c, n);
    gap->next += n;
}

// A restart that waits for the next NMI to run the game: LD SP,nn (Coleco RAM), a few instructions,
// then JR $ with no EI or HALT before it (Popeye, after a death: its NMI handler jumps here and never
// returns). The NMI can't be masked on a ColecoVision; on the NABU it is the loader's maskable
// interrupt, still off because the handler never returned, so the game stopped. The LD SP,nn becomes a
// JP to code that sets SP, clears the pending VDP interrupt (keeping its status bits for
// READ_REGISTER, as wrap_nmi does), turns interrupts on and jumps back.
static void idle_restart_ei(uint8_t* rom, size_t rom_len, const CodeMap* code, Gap* gap) {
    if (!gap || !gap->saved) return;
    for (size_t i = 0; i + 3 < rom_len; i++) {
        if (rom[i] != 0x31 || rom[i + 2] < 0x70 || rom[i + 2] > 0x73 || !code->xstart[i] || code->xconflict[i]) continue;
        size_t pc = i + 3, end = i + 20 < rom_len ? i + 20 : rom_len;
        while (pc + 1 < end && !(rom[pc] == 0x18 && rom[pc + 1] == 0xFE) && rom[pc] != 0xFB && rom[pc] != 0x76) pc += z80_len(rom, rom_len, pc);
        if (pc + 1 >= end || rom[pc] != 0x18 || rom[pc + 1] != 0xFE) continue;
        int s = gap->saved, back = 0x8000 + (int)i + 3, n = 0;
        uint8_t c[24] = {0x31, rom[i + 1], rom[i + 2],                       // LD SP,nn
                         0xF5, 0xE5, 0xDB, 0xA1, 0x21, s & 0xFF, s >> 8,     // PUSH AF / PUSH HL / IN A,($A1) / LD HL,saved
                         0xB6, 0x77, 0xE1, 0xF1, 0xFB,                       // OR (HL) / LD (HL),A / POP HL / POP AF / EI
                         0xC3, back & 0xFF, back >> 8};                      // JP back
        n = 18;
        if (gap->next + n > gap->end) { printf("\n    [0x%04X] Restart waiting for the NMI: no room!", (uint32_t)i); return; }
        memcpy(&gap->stub[gap_off(gap, gap->next)], c, n);
        printf("\n    [0x%04X] Restart waiting for the NMI (LD SP / JR $): turns interrupts on (0x%04X)", (uint32_t)i, gap->next);
        rom[i] = 0xC3; rom[i + 1] = gap->next & 0xFF; rom[i + 2] = gap->next >> 8;
        gap->next += n;
    }
}

// The I register as a variable: LD I,A / LD A,I (Opcode's Yie Ar Kung-Fu keeps a flag there and tests it
// in its NMI handler). A ColecoVision's NMI doesn't use I, but the NABU loader runs its interrupts in
// IM 2 with I = the vector table's page: once the game changes I, the next interrupt jumps through a
// random word and the game crashes. Each traced LD I,A becomes a JP to code that stores A in a byte in
// the free space; each LD A,I to code that loads that byte, with S and Z from it and P/V (IFF2) and
// carry from a real LD A,I. The instructions after it, up to 3 bytes, are moved there (not relative
// jumps or RSTs, whose return address the converter's RST dispatchers check), then a JP back. An
// LD A,I / OR A (or AND A) that can't be moved becomes CALL "LD A,(shadow) / OR A / RET".
// Untraced sites count too when they can only be code: LD A,n / LD I,A, XOR A / LD I,A, and LD A,I
// followed by OR A, AND A or LD (nn),A (Pac-Man Collection's menu: 8A92, 9371, 9DAB).
// lo: the first ROM offset looked at (a megacart's extra banks: only their C000 half, 4000h).
static void i_register(uint8_t* rom, size_t rom_len, const CodeMap* code, Gap* gap, size_t lo) {
    if (!gap || !gap->next) return;
    int shadow = gap->i_shadow, tmp = gap->i_tmp, sets_i = shadow >= 0;   // (a megacart's banks share one shadow)
    for (size_t i = lo; i + 2 < rom_len; i++)                // (games that only read IFF2 with LD A,I are left alone)
        if (rom[i] == 0xED && rom[i + 1] == 0x47 && code->xstart[i] && !code->xconflict[i]) sets_i = 1;
    if (!sets_i) return;
    int s_or = -1, s_and = -1;
    for (size_t i = lo; i + 2 < rom_len; i++) {
        if (rom[i] != 0xED || (rom[i + 1] != 0x47 && rom[i + 1] != 0x57)) continue;
        if (!code->xstart[i] || code->xconflict[i]) {
            int own = code->owner[i];
            if (own != -1 && (size_t)own != i && !code->conflict[i]) continue;          // inside a traced instruction
            if (rom[i + 1] == 0x47 ? !((i >= 2 && rom[i - 2] == 0x3E) || (i >= 1 && rom[i - 1] == 0xAF))
                                   : !(rom[i + 2] == 0xB7 || rom[i + 2] == 0xA7 || rom[i + 2] == 0x32)) continue;
        }
        int ld_i = rom[i + 1] == 0x47, ok = 1;
        size_t pc = i + 2;
        while (pc - i < 3) {
            uint8_t op;
            if (pc >= rom_len) { ok = 0; break; }
            op = rom[pc];
            if (op == 0x18 || op == 0x20 || op == 0x28 || op == 0x30 || op == 0x38 || op == 0x10 || (op & 0xC7) == 0xC7) { ok = 0; break; }
            pc += z80_len(rom, rom_len, pc);
        }
        int flag_op = !ld_i && (rom[i + 2] == 0xB7 || rom[i + 2] == 0xA7);
        if ((!ok || pc > rom_len) && !flag_op) { printf("\n    [0x%04X] %s: the next instruction can't be moved, left alone", (uint32_t)i, ld_i ? "LD I,A" : "LD A,I"); continue; }
        if (shadow < 0) {
            if (gap->next + 2 > gap->end) { printf("\n    [0x%04X] I register: no room!", (uint32_t)i); return; }
            shadow = gap->i_shadow = gap->next; tmp = gap->i_tmp = gap->next + 1;
            gap->stub[gap_off(gap, shadow)] = 0; gap->stub[gap_off(gap, tmp)] = 0;
            gap->next += 2;
        }
        if (!ok || pc > rom_len) {                                  // LD A,I / OR A (AND A): CALL a 3-byte equivalent
            int* sp = rom[i + 2] == 0xB7 ? &s_or : &s_and;
            if (*sp < 0) {
                if (gap->next + 5 > gap->end) { printf("\n    [0x%04X] I register: no room!", (uint32_t)i); return; }
                const uint8_t e[5] = {0x3A, (uint8_t)shadow, (uint8_t)(shadow >> 8), rom[i + 2], 0xC9};
                *sp = gap->next; memcpy(&gap->stub[gap_off(gap, gap->next)], e, 5); gap->next += 5;
            }
            printf("\n    [0x%04X] LD A,I / %s: the I register is the loader's (IM 2), CALL 0x%04X (the game's I is kept at 0x%04X)",
                   (uint32_t)i, rom[i + 2] == 0xB7 ? "OR A" : "AND A", *sp, shadow);
            rom[i] = 0xCD; rom[i + 1] = *sp & 0xFF; rom[i + 2] = *sp >> 8;
            continue;
        }
        int moved = (int)(pc - i - 2), back = 0x8000 + (int)pc, n = 0;
        uint8_t c[48];
        if (ld_i) {
            c[n++] = 0x32; c[n++] = shadow & 0xFF; c[n++] = shadow >> 8;                         // LD (shadow),A
        } else {
            const uint8_t e[] = {0xE5, 0xED, 0x57, 0xF5, 0xE1, 0x7D, 0xE6, 0x05,             // PUSH HL / LD A,I / PUSH AF / POP HL / LD A,L / AND 5
                                 0x32, tmp & 0xFF, tmp >> 8, 0x3A, shadow & 0xFF, shadow >> 8,  // LD (tmp),A / LD A,(shadow)
                                 0xB7, 0xF5, 0xE1, 0x7D, 0xE6, 0xFA, 0x6F,                      // OR A / PUSH AF / POP HL / LD A,L / AND FA / LD L,A
                                 0x3A, tmp & 0xFF, tmp >> 8, 0xB5, 0x6F, 0xE5, 0xF1, 0xE1};     // LD A,(tmp) / OR L / LD L,A / PUSH HL / POP AF / POP HL
            memcpy(c, e, sizeof e); n = sizeof e;
        }
        memcpy(&c[n], &rom[i + 2], moved); n += moved;
        c[n++] = 0xC3; c[n++] = back & 0xFF; c[n++] = back >> 8;                                   // JP back
        if (gap->next + n > gap->end) { printf("\n    [0x%04X] I register: no room!", (uint32_t)i); return; }
        memcpy(&gap->stub[gap_off(gap, gap->next)], c, n);
        printf("\n    [0x%04X] %s: the I register is the loader's (IM 2), the game's is kept at 0x%04X (0x%04X)",
               (uint32_t)i, ld_i ? "LD I,A" : "LD A,I", shadow, gap->next);
        rom[i] = 0xC3; rom[i + 1] = gap->next & 0xFF; rom[i + 2] = gap->next >> 8;
        for (int k = 3; k < moved + 2; k++) rom[i + k] = 0x00;
        gap->next += n;
    }
}

// Jumps into the BIOS's insides: a few games JP / CALL a ColecoVision BIOS routine that isn't in the
// jump table (Poker, Snake demo, Globe Quiz...: JP 0295, the sound reset without its first instructions).
// The loader's BIOS is a rewrite: its jump table and the entries games use are at the ColecoVision
// addresses, but the rest of the routines moved, and 0295 is the middle of an instruction there (the
// game ran a stray LD (BC),A that broke the BIOS's sound, and the screen went black). Each traced JP /
// CALL to a routine that moved goes to where it is in the loader's BIOS (bios_map, from bios.sym's
// labels; loader\bios_map.py makes the table).
static const uint16_t bios_map[][2] = {
    {0x0048,0x0050}, {0x004C,0x0054}, {0x004F,0x0046}, {0x0050,0x0047}, {0x0081,0x0080}, {0x00A3,0x009F}, {0x00B7,0x00B2}, {0x00C4,0x00BE},
    {0x00D0,0x00C5}, {0x00D6,0x00CA}, {0x00DA,0x00CE}, {0x00E5,0x00D9}, {0x00F4,0x00E3}, {0x00F8,0x00E6}, {0x00FC,0x00E9}, {0x010C,0x00F8},
    {0x012F,0x0118}, {0x015D,0x0143}, {0x0161,0x0146}, {0x0164,0x0345}, {0x016F,0x0350}, {0x0175,0x0D3E}, {0x0190,0x1CE3}, {0x01A6,0x1C02},
    {0x01B9,0x01B8}, {0x0220,0x021F}, {0x0295,0x0293}, {0x0297,0x02D4}, {0x02AB,0x029D}, {0x02CB,0x02BB}, {0x02D3,0x02C2}, {0x02D6,0x02C5},
    {0x02E6,0x02E7}, {0x0335,0x0353}, {0x034E,0x0356}, {0x035F,0x0379}, {0x0391,0x03A2}, {0x039E,0x03AE}, {0x03A4,0x03B3}, {0x03C6,0x03D5},
    {0x03D2,0x03E0}, {0x03F0,0x03FC}, {0x03F4,0x0400}, {0x03F8,0x0404}, {0x03FA,0x0406}, {0x0419,0x041F}, {0x0429,0x042D}, {0x0445,0x0448},
    {0x0461,0x045C}, {0x0472,0x046D}, {0x0478,0x0057}, {0x047C,0x005A}, {0x0488,0x0473}, {0x04A3,0x048A}, {0x04C6,0x04A7}, {0x04D5,0x04B6},
    {0x04E5,0x04C6}, {0x04E7,0x04F9}, {0x0530,0x0558}, {0x0572,0x05BB}, {0x0588,0x05D0}, {0x0591,0x05D9}, {0x0594,0x0534}, {0x05B5,0x0551},
    {0x05BC,0x0596}, {0x05C2,0x059C}, {0x05CE,0x05A7}, {0x05F1,0x04C8}, {0x0600,0x04D7}, {0x0623,0x05F3}, {0x0655,0x1A87}, {0x0664,0x1A96},
    {0x0669,0x060F}, {0x0679,0x1ABC}, {0x0682,0x1AC4}, {0x06B3,0x1AF1}, {0x06B9,0x1AF5}, {0x06BC,0x1AFA}, {0x06C7,0x05DC}, {0x06D8,0x05ED},
    {0x06E3,0x0616}, {0x06FF,0x063B}, {0x0744,0x067D}, {0x074B,0x0683}, {0x0766,0x069E}, {0x0771,0x06A8}, {0x077F,0x06B6}, {0x0780,0x06B7},
    {0x0794,0x06CB}, {0x07A8,0x06DF}, {0x07DD,0x0711}, {0x0885,0x0883}, {0x0898,0x0895}, {0x08A2,0x089F}, {0x08CB,0x08C8}, {0x08DB,0x08D5},
    {0x08DF,0x0630}, {0x08E0,0x071B}, {0x0900,0x0735}, {0x0914,0x0745}, {0x0955,0x08D8}, {0x0999,0x08E0}, {0x09CA,0x0750}, {0x09D5,0x13FF},
    {0x09D8,0x1402}, {0x09FD,0x075D}, {0x0A00,0x0760}, {0x0A54,0x0786}, {0x0A7E,0x07AA}, {0x0A87,0x08EB}, {0x0A98,0x08FA}, {0x0B07,0x0968},
    {0x0B0A,0x096B}, {0x0B25,0x0984}, {0x0B31,0x0990}, {0x0B39,0x0998}, {0x0B51,0x09AF}, {0x0B64,0x09BF}, {0x0B76,0x09CE}, {0x0B7D,0x09D5},
    {0x0BB8,0x0A00}, {0x0BD6,0x0A18}, {0x0BD9,0x0A1B}, {0x0C1A,0x0A5A}, {0x0C1D,0x0A5D}, {0x0C38,0x0A78}, {0x0C55,0x0A94}, {0x0C7C,0x0A8A},
    {0x0C84,0x0AB4}, {0x0CA5,0x0AD5}, {0x0CB4,0x0AE4}, {0x0CBC,0x0AEC}, {0x0CCF,0x0AFF}, {0x0CD4,0x0B04}, {0x0CDD,0x0B0A}, {0x0CFC,0x0B26},
    {0x0D03,0x0B2D}, {0x0D0E,0x0B38}, {0x0D18,0x0B42}, {0x0D4C,0x0B71}, {0x0D60,0x0B84}, {0x0D69,0x0B8D}, {0x0D87,0x0BA5}, {0x0D96,0x0BAF},
    {0x0D98,0x0BAF}, {0x0DA5,0x0BBB}, {0x0DAC,0x0BC2}, {0x0DE3,0x0BF5}, {0x0DEA,0x0BFC}, {0x0E17,0x0C26}, {0x0E28,0x0C37}, {0x0E2F,0x0C3D},
    {0x0E4B,0x0C56}, {0x0E51,0x0C5C}, {0x0E58,0x0C63}, {0x0E5C,0x0C67}, {0x0E5F,0x0C6A}, {0x0E7B,0x0C82}, {0x0E87,0x0C8E}, {0x0E93,0x0C9A},
    {0x0E9F,0x0CA6}, {0x0EA2,0x0CA9}, {0x0ED3,0x0CDA}, {0x0EF2,0x0CF9}, {0x0F1C,0x0D23}, {0x0F3A,0x1285}, {0x0F49,0x1292}, {0x0F5F,0x12A8},
    {0x0F79,0x12C2}, {0x0F8B,0x12D1}, {0x0F8D,0x12D3}, {0x0F8F,0x12D5}, {0x0FCF,0x1306}, {0x0FD7,0x130F}, {0x0FEE,0x1322}, {0x0FFD,0x132F},
    {0x100D,0x133F}, {0x1019,0x1349}, {0x1020,0x134C}, {0x105A,0x137D}, {0x106E,0x138F}, {0x1074,0x1395}, {0x1095,0x13B5}, {0x109C,0x13BE},
    {0x10A6,0x13C8}, {0x10B6,0x13B9}, {0x10D6,0x13E2}, {0x10DE,0x13EA}, {0x10E6,0x13F2}, {0x10E9,0x13F4}, {0x10EF,0x13FA}, {0x1116,0x1117},
    {0x1137,0x10E9}, {0x113D,0x1166}, {0x1146,0x116F}, {0x1148,0x1172}, {0x117D,0x10FA}, {0x1182,0x10FD}, {0x1189,0x1103}, {0x1199,0x10A2},
    {0x11AA,0x10AF}, {0x11BC,0x10C3}, {0x11E8,0x119A}, {0x11F3,0x11A5}, {0x1214,0x11C4}, {0x1229,0x124D}, {0x1231,0x1275}, {0x1248,0x11F4},
    {0x127A,0x1218}, {0x127E,0x121B}, {0x1282,0x121F}, {0x1285,0x1222}, {0x12AB,0x1269}, {0x12AF,0x126C}, {0x12B3,0x1270}, {0x12B6,0x1273},
    {0x12DB,0x1241}, {0x12E3,0x1248}, {0x12E6,0x124B}, {0x130B,0x11E8}, {0x130F,0x11EB}, {0x1313,0x11EF}, {0x1316,0x11F2}, {0x1319,0x07AE},
    {0x1330,0x07B7}, {0x1352,0x0149}, {0x1356,0x07C4}, {0x13B7,0x016E}, {0x13FF,0x1A43}, {0x1439,0x1A55}, {0x1946,0x193C}, {0x1949,0x193F},
    {0x1951,0x1947}, {0x196C,0x1956}, {0x196E,0x195B}, {0x1978,0x1965}, {0x1B40,0x1B4A}, {0x1B5C,0x1B56}, {0x1B6A,0x1B64}, {0x1B72,0x1B6C},
    {0x1BCD,0x1BCC}, {0x1BE0,0x1BDE}, {0x1BEB,0x1BE9}, {0x1BEC,0x1BEA}, {0x1C6B,0x1C65}, {0x1CDB,0x1CDA}, {0x1D14,0x1D0D}, {0x1D49,0x1D4A},
    {0x1D8C,0x1DED}, {0x1DB3,0x1DC0}, {0x1E02,0x1DA3}, {0x1E55,0x1E43}, {0x1E5D,0x1E49}, {0x1E72,0x1E5B}, {0x1E89,0x1E6C}, {0x1E90,0x1E73},
    {0x1E92,0x1E75}, {0x1E9A,0x1E7C}, {0x1EA5,0x1E83}, {0x1EA7,0x1E85}, {0x1EB4,0x1E94}, {0x1EBC,0x1E9C}, {0x1EC9,0x1EA9}, {0x1EEE,0x1ECA},
    {0x1EFB,0x1ED7}, {0x1F03,0x1EDC}, {0x1F06,0x1EDF}, {0x1F19,0x1EF0}, {0x1F53,0x1F29},
};
static void bios_entries(uint8_t* rom, size_t rom_len, const CodeMap* code) {
    for (size_t i = 0; i + 2 < rom_len; i++) {
        uint8_t op = rom[i];
        if (op != 0xC3 && op != 0xCD && (op & 0xC7) != 0xC2 && (op & 0xC7) != 0xC4) continue;
        if (!code->xstart[i] || code->xconflict[i]) continue;
        int t = rom[i + 1] | rom[i + 2] << 8;
        if (t >= 0x2000) continue;
        for (size_t k = 0; k < sizeof bios_map / sizeof bios_map[0]; k++) {
            if (bios_map[k][0] != t) continue;
            printf("\n    [0x%04X] %s 0x%04X: a BIOS routine that moved in the loader's BIOS -> 0x%04X",
                   (uint32_t)i, op == 0xCD || (op & 0xC7) == 0xC4 ? "CALL" : "JP", t, bios_map[k][1]);
            rom[i + 1] = bios_map[k][1] & 0xFF; rom[i + 2] = bios_map[k][1] >> 8;
            break;
        }
    }
}

// Wait for the next frame: DI / HALT / EI / RET (Prince, Klondike, Minesweeper). A ColecoVision's NMI
// wakes the HALT with interrupts off; the NABU's maskable VDP interrupt can't, so the game stopped for
// good. EI / HALT does the same here: the frame interrupt runs the NMI handler and the HALT ends.
static void halt_di_ei(uint8_t* rom, size_t rom_len) {
    for (size_t i = 0; i + 3 < rom_len; i++) {
        if (rom[i] != 0xF3 || rom[i + 1] != 0x76 || rom[i + 2] != 0xFB || rom[i + 3] != 0xC9) continue;
        printf("\n    [0x%04X] DI / HALT waiting for the NMI -> EI / HALT", (uint32_t)i);
        rom[i] = 0xFB;
    }
}

// The stack pointer as a data pointer: LD (nn),SP, then LD SP,HL (or IX / IY / nn) and POPs through a
// table in the cart, then LD SP,(nn) (Defender's drawing routines). The game keeps the VDP interrupt
// off around it, but on the NABU the keyboard and joystick interrupt can still come, and its pushes
// land in the table, which here is RAM: the game's data and code get overwritten. The save becomes a
// CALL that saves SP, notes whether interrupts were on and turns them off; each restore a JP that
// restores SP and turns them back on if they were.
static void sp_trick_di(uint8_t* rom, size_t rom_len, const CodeMap* code, Gap* gap) {
    if (!gap || !gap->next) return;
    int vars[8], flags[8], saves[8], nv = 0;
    for (size_t i = 0; i + 4 < rom_len; i++) {
        if (rom[i] != 0xED || rom[i + 1] != 0x73 || !code->xstart[i] || code->xconflict[i]) continue;
        size_t pc = i + 4;
        int sets_sp = 0;
        for (int k = 0; k < 6 && pc + 1 < rom_len && !sets_sp; k++) {
            uint8_t op = rom[pc], op2 = rom[pc + 1];
            if (op == 0xF9 || op == 0x31 || ((op == 0xDD || op == 0xFD) && op2 == 0xF9)) sets_sp = 1;
            pc += z80_len(rom, rom_len, pc);
        }
        if (!sets_sp) continue;
        int nn = rom[i + 2] | rom[i + 3] << 8, v = 0;
        while (v < nv && vars[v] != nn) v++;
        if (v == nv) {
            if (nv == 8) continue;
            int flag = gap->next, s = gap->next + 1;                       // flag byte, then the save routine
            uint8_t c[32] = {0, 0xF5, 0xE5, 0x21, 0x06, 0x00, 0x39, 0x22, nn & 0xFF, nn >> 8,   // PUSH AF / PUSH HL / LD HL,6 / ADD HL,SP / LD (nn),HL
                             0xED, 0x57, 0xEA, 0, 0, 0xED, 0x57, 0xEA, 0, 0,          // LD A,I / JP PE,on (asked twice: NMOS IFF2 quirk)
                             0xAF, 0x18, 0x02, 0x3E, 0x01,                           // XOR A / JR st / on: LD A,1
                             0x32, flag & 0xFF, flag >> 8, 0xF3, 0xE1, 0xF1, 0xC9};  // st: LD (flag),A / DI / POP HL / POP AF / RET
            int on = s + 22;
            c[13] = c[18] = on & 0xFF; c[14] = c[19] = on >> 8;
            if (gap->next + 32 > gap->end) { printf("\n    [0x%04X] Stack pointer as a data pointer: no room!", (uint32_t)i); return; }
            memcpy(&gap->stub[gap_off(gap, gap->next)], c, 32);
            gap->next += 32;
            vars[nv] = nn; flags[nv] = flag; saves[nv] = s; nv++;
        }
        printf("\n    [0x%04X] LD ($%04X),SP before the stack is used as a data pointer: interrupts off (0x%04X)", (uint32_t)i, nn, saves[v]);
        rom[i] = 0xCD; rom[i + 1] = saves[v] & 0xFF; rom[i + 2] = saves[v] >> 8; rom[i + 3] = 0x00;
    }
    for (size_t i = 0; nv && i + 4 < rom_len; i++) {
        if (rom[i] != 0xED || rom[i + 1] != 0x7B || !code->xstart[i] || code->xconflict[i]) continue;
        int nn = rom[i + 2] | rom[i + 3] << 8, v = 0, back = 0x8000 + (int)i + 4, f;
        while (v < nv && vars[v] != nn) v++;
        if (v == nv) continue;
        f = flags[v];
        uint8_t c[16] = {0xED, 0x7B, nn & 0xFF, nn >> 8, 0xF5, 0x3A, f & 0xFF, f >> 8,    // LD SP,(nn) / PUSH AF / LD A,(flag)
                         0xB7, 0x28, 0x01, 0xFB, 0xF1, 0xC3, back & 0xFF, back >> 8};   // OR A / JR Z,+1 / EI / POP AF / JP back
        if (gap->next + 16 > gap->end) { printf("\n    [0x%04X] Stack pointer as a data pointer: no room!", (uint32_t)i); return; }
        memcpy(&gap->stub[gap_off(gap, gap->next)], c, 16);
        printf("\n    [0x%04X] LD SP,($%04X) after it: interrupts back as they were (0x%04X)", (uint32_t)i, nn, gap->next);
        rom[i] = 0xC3; rom[i + 1] = gap->next & 0xFF; rom[i + 2] = gap->next >> 8; rom[i + 3] = 0x00;
        gap->next += 16;
    }
}

// VDP port loaded into C other than by LD C,n (e.g. CVBasic's LD BC,$80BE before OTIR). Only patched
// in traced code where C then really is used as a port, so 16-bit constants ending in $BE/$BF are safe.
StandardPatch smart_port_patches[] = {
    {"LD BC,nn (C=0xBE) port",  {0x01, 0xBE},       {0x01, 0xA0},       2},
    {"LD BC,nn (C=0xBF) port",  {0x01, 0xBF},       {0x01, 0xA1},       2},
    {"LD A,0xBE / LD C,A port", {0x3E, 0xBE, 0x4F}, {0x3E, 0xA0, 0x4F}, 3},
    {"LD A,0xBF / LD C,A port", {0x3E, 0xBF, 0x4F}, {0x3E, 0xA1, 0x4F}, 3},
};

// Megacart code banks (-xbanks): more C000 halves, converted with the same fixed bank. Their call
// sites join the main image's (one set of RST dispatchers); fixed-bank patches are merged.
static uint8_t* xbanks = NULL;          // the extra banks, 16KB each
static int nxbanks = 0;
static uint8_t* xbanks_out = NULL;      // their converted C000 halves
static int xbank_ids[16];               // megacart: each extra bank's number (for messages and known data)
static uint16_t xbank_crc;              // megacart: the image's CRC16 (known_bank_data)
static int xbank_mega = 0;              // the extra banks come from a megacart (else -xbanks)

static void add_site(Vector* v, int site) {
    for (int k = 0; k < v->nsites; k++) if (v->sites[k] == site) return;
    if (v->nsites < 1024) v->sites[v->nsites++] = site;
}

// The pattern patches and the vector / sound port / IN A,(C) RST patches; sites go to vecs.
static void collect_patches(uint8_t* rom, size_t rom_len, const CodeMap* code, int smart_ports, Gap* gap,
                            Vector* vecs, int* pnv, int* preads_fc) {
    int nv = *pnv, reads_fc = *preads_fc;
    printf("\n  Applying Standard Patches:");
    for (int i = 0; i < 8; i++) {
        int accept = std_patches[i].search[0] == 0x0E ? ACCEPT_LDC : ACCEPT_ANY;   // LD C,$BE / LD C,$BF
        find_and_replace(rom, rom_len, std_patches[i].search, std_patches[i].replace, std_patches[i].len, std_patches[i].desc, code, accept);
    }
    if (smart_ports) {
        for (int i = 0; i < 4; i++)
            find_and_replace(rom, rom_len, smart_port_patches[i].search, smart_port_patches[i].replace,
                             smart_port_patches[i].len, smart_port_patches[i].desc, code, ACCEPT_PORT);
    }

    printf("\n  Applying Interrupt Patches:");
    find_and_replace(rom, rom_len, im1_op, nops, 2, "IM 1 -> NOPs", code, ACCEPT_IM1);
    // Real BIOS $1987 is GAME_OPT after its screen clear (The Yolk's on You calls it directly). The
    // NABU loader's BIOS is a rewrite where $1987 is mid-instruction; its equivalent point is $197C.
    static const uint8_t opt_old[3] = {0xCD, 0x87, 0x19}, opt_new[3] = {0xCD, 0x7C, 0x19};
    find_and_replace(rom, rom_len, opt_old, opt_new, 3, "CALL $1987 (GAME_OPT text) -> $197C", code, ACCEPT_IM1);
    find_and_replace(rom, rom_len, di_op, nops, 1, "DI -> NOP", code, ACCEPT_DI);

    printf("\n  Applying Vector Patches:");
    for (int i = 0; i < 6; i++) {
        int found = find_and_replace(rom, rom_len, vec_patches[i].search, vec_patches[i].replace, 2, vec_patches[i].desc, code, ACCEPT_ANY);
        if (found > 0) {
            uint8_t v_data[3];
            memcpy(v_data, vec_patches[i].vector_data, 3);
            if (vec_patches[i].search[0] == 0xDB && vec_patches[i].search[1] == 0xFC) reads_fc = 1;
            int k = 0;
            while (k < nv && vecs[k].slot != vec_patches[i].vector_offset) k++;       // same slot: merge sites
            if (k == nv) { vecs[k].slot = vec_patches[i].vector_offset; memcpy(vecs[k].data, v_data, 3); vecs[k].desc = vec_patches[i].desc; vecs[k].nsites = 0; nv++; }
            for (int s = 0; s < last_nsites; s++) add_site(&vecs[k], last_sites[s]);
        }
    }
    // The sound chip answers to every port $E0-$FF (Wonder Boy writes $F0). $FF and $E0 are patched
    // anywhere above; the others in traced code, or right after LD A,n / OR n with a sound latch byte
    // (bit 7 set; Wonder Boy's music driver is only reached through a jump table).
    const VectorPatch* snd = &vec_patches[0];
    int ks = 0;
    while (ks < nv && vecs[ks].slot != snd->vector_offset) ks++;
    for (int p = 0xE1; p < 0xFF; p++) {
        static char descs[0x20][32];
        char* desc = descs[p & 0x1F];
        snprintf(desc, sizeof descs[0], "Sound port 0x%X (RST 0x30)", p);
        const uint8_t out_p[2] = {0xD3, (uint8_t)p};
        if (find_and_replace(rom, rom_len, out_p, snd->replace, 2, desc, code, ACCEPT_SOUND) > 0) {
            if (ks == nv) { vecs[ks].slot = snd->vector_offset; memcpy(vecs[ks].data, snd->vector_data, 3); vecs[ks].desc = desc; vecs[ks].nsites = 0; nv++; }
            for (int s = 0; s < last_nsites; s++) add_site(&vecs[ks], last_sites[s]);
        }
    }
    // Controllers read with IN A,(C), C = port (Wonder Boy): if traced code loads C with a controller
    // port (LD C,$FC / LD C,$FF, or LD BC,nn with it: Suite Macabre), IN A,(C) -> RST $08 -> the loader's read_port_c, which reads a
    // controller for C = $E0-$FF and the real port otherwise.
    int via_c = 0, via_c_fc = 0;
    for (size_t i = 0; i + 1 < rom_len; i++)
        if ((rom[i] == 0x0E || rom[i] == 0x01) && (rom[i + 1] == 0xFC || rom[i + 1] == 0xFF) && code->xstart[i] && !code->xconflict[i]) {
            via_c = 1;
            if (rom[i + 1] == 0xFC) via_c_fc = 1;
        }
    if (via_c && gap && gap->read_port_c) {
        static const uint8_t in_c[2] = {0xED, 0x78}, rst08[2] = {0xCF, 0x00};
        if (find_and_replace(rom, rom_len, in_c, rst08, 2, "IN A,(C) controller (RST 0x08)", code, ACCEPT_IM1) > 0) {
            int k = 0;
            while (k < nv && vecs[k].slot != rst_slot(0x08)) k++;
            Vector* v = &vecs[k];
            if (k == nv) { nv++; v->slot = rst_slot(0x08); v->desc = "IN A,(C) (RST 0x08)"; v->nsites = 0; }
            v->data[0] = 0xC3; v->data[1] = gap->read_port_c & 0xFF; v->data[2] = gap->read_port_c >> 8;
            for (int s = 0; s < last_nsites; s++) add_site(v, last_sites[s]);
            if (via_c_fc) reads_fc = 1;
        }
    }
    *pnv = nv; *preads_fc = reads_fc;
}

// Sequential VRAM reads with INIR right after the read address was sent from HL (Newcoleco's library: LD A,L /
// OUT ($BF),A / LD A,H / OUT ($BF),A / [PUSH HL] / LD BC,nn$BE / LD HL,buffer / INIR, in about 20 homebrews;
// Jungle Hunt: OUT (C),L / OUT (C),H / LD HL,buffer / LD BC,nn$BE / INIR). A PICO9918 with v1.2 firmware slips
// a byte at some addresses on sequential reads (MAME doesn't show it): Amy Chess's pieces were garbled. The
// LD BC / LD HL / INIR become CALL a routine that reads through the loader's addressed READ_VRAM ($1FE2, an
// address for each byte), with HL, B and C as INIR leaves them and A and DE kept: PUSH AF / PUSH DE / EX DE,HL /
// LD HL,buffer / LD BC,count / CALL $1FE2 / POP DE / POP AF / RET.
static void inir_addressed(uint8_t* rom, size_t n, Gap* gap) {
    if (!gap || !gap->next) return;
    for (size_t i = 0; i + 14 <= n; i++) {
        int site = -1, buf = 0, cnt = 0;
        if (rom[i] == 0x7D && rom[i + 1] == 0xD3 && rom[i + 2] == 0xBF && rom[i + 3] == 0x7C && rom[i + 4] == 0xD3 && rom[i + 5] == 0xBF) {
            size_t k = i + 6 + (rom[i + 6] == 0xE5);
            if (k + 8 <= n && rom[k] == 0x01 && rom[k + 1] == 0xBE && rom[k + 3] == 0x21 && rom[k + 6] == 0xED && rom[k + 7] == 0xB2) {
                site = (int)k; cnt = rom[k + 2]; buf = rom[k + 4] | rom[k + 5] << 8;
            }
        } else if (rom[i] == 0xED && rom[i + 1] == 0x69 && rom[i + 2] == 0xED && rom[i + 3] == 0x61 && rom[i + 4] == 0x21 &&
                   rom[i + 7] == 0x01 && rom[i + 8] == 0xBE && rom[i + 10] == 0xED && rom[i + 11] == 0xB2) {
            site = (int)i + 4; buf = rom[i + 5] | rom[i + 6] << 8; cnt = rom[i + 9];
        }
        if (site < 0) continue;
        if (gap->next + 15 > gap->end) { printf("\n    [0x%04X] INIR from VRAM: no room!", (uint32_t)site); return; }
        const uint8_t c[15] = {0xF5, 0xD5, 0xEB, 0x21, buf & 0xFF, buf >> 8, 0x01, (uint8_t)cnt, 0x00,
                               0xCD, 0xE2, 0x1F, 0xD1, 0xF1, 0xC9};
        memcpy(&gap->stub[gap_off(gap, gap->next)], c, 15);
        printf("\n    [0x%04X] INIR from VRAM (address from HL): addressed reads (0x%04X)", (uint32_t)site, gap->next);
        const uint8_t p[8] = {0xCD, (uint8_t)(gap->next & 0xFF), (uint8_t)(gap->next >> 8), 0x18, 0x03, 0x00, 0x00, 0x00};   // CALL / JR +3
        memcpy(&rom[site], p, 8);
        gap->next += 15;
    }
}

// Amy Studio speech (Amy Chess, Globe Quiz, Solar System, the Space Taxi voice demo): each sample is a
// level from a table of SN76489 volume triples (9x Bx Dx, the three tone channels summed as a DAC),
// written by ADD HL,DE / LD B,3 / OTIR / DEC HL x3 / DEC A / JR Z / CALL delay / JR back. Through the
// sound emulation the three bytes cost about 1000 cycles more than on a ColecoVision, so the speech
// played 3x slow, and the SN's 2 dB volume steps don't match the AY's. Here:
//  - LD B,3 / OTIR -> CALL a routine that writes the triple straight to AY registers 8-10. That takes
//    about as long as the OTIR on a ColecoVision, where the SN76489 holds the Z80 in WAIT for each byte
//    (MAME, Amy Chess: 590 cycles a sample there, 541 here): the delays get 3 loops of 17 cycles more;
//  - the table is rebuilt for the AY's volume curve (each level's summed SN amplitude, the closest sum
//    of three AY levels);
//  - the routine that sets the tone periods for speech (LD BC,$0381 ... LD A,$FF / OUT ($FF),A / RET)
//    also turns the AY's tones off (mixer $7F: the volumes are then plain DAC levels; period 1 on the AY
//    is a 112 kHz tone, not a constant), and the silence after speech (LD A,$9F / OUT ($FF),A,
//    $BF, $DF) turns them back on (mixer $78, as the loader sets it).
// The delays: CALL to PUSH BC / LD B,n / NOP / DJNZ (n + 3), or PUSH BC / PUSH IY / POP BC / NOP / DJNZ
// with IY set by PUSH BC / POP IY before the start (that becomes a CALL that adds 3 to B and C).
// The patterns are long enough to need no tracing (Solar System's players are reached through tables).
// amytts\amytts.asm (python amytts\build.py): the clip lookup and text to speech; words at AMY_TTS_REL[] are
// addresses from 0 (add the base); AMY_TTS_MASK = current_interrupt_mask's address, AMY_TTS_OK the flag
static const uint8_t AMY_TTS[275] = {0xD5, 0xE5, 0xEB, 0x21, 0x13, 0x01, 0x4E, 0x23, 0x46, 0x23, 0x78, 0xB1, 0x28, 0x1F, 0x79, 0xBB, 0x20, 0x04, 0x78, 0xBA, 0x28, 0x04, 0x23, 0x23, 0x18, 0xEC, 0x5E, 0x23, 0x56, 0x1A, 0xB7, 0x28, 0x10, 0x3A, 0x12, 0x01, 0xFE, 0x02, 0x28, 0x05, 0xCD, 0x35, 0x00, 0x38, 0x04, 0xE1, 0xD1, 0xB7, 0xC9, 0xE1, 0xD1, 0x37, 0xC9, 0xED, 0x57, 0xF5, 0xF3, 0x3E, 0x0E, 0xD3, 0x41, 0x3E, 0x80, 0xD3, 0x40, 0x3A, 0x12, 0x01, 0xB7, 0x20, 0x1E, 0x3E, 0xBA, 0xCD, 0xD6, 0x00, 0x3E, 0x14, 0xCD, 0xD6, 0x00, 0x06, 0x01, 0xCD, 0xF5, 0x00, 0x0E, 0x02, 0x38, 0x04, 0xB7, 0x20, 0x01, 0x0D, 0x79, 0x32, 0x12, 0x01, 0x3D, 0x20, 0x4B, 0x3E, 0xE0, 0xCD, 0xD6, 0x00, 0x1A, 0x47, 0xCD, 0xD6, 0x00, 0x13, 0x1A, 0xCD, 0xD6, 0x00, 0x10, 0xF9, 0x3E, 0x07, 0xD3, 0x41, 0x3E, 0x7F, 0xD3, 0x40, 0x06, 0x05, 0xCD, 0xF5, 0x00, 0x38, 0x2B, 0xFE, 0xF0, 0x28, 0x1D, 0x4F, 0x3E, 0x08, 0xD3, 0x41, 0x79, 0xD3, 0x40, 0x3E, 0x09, 0xD3, 0x41, 0x79, 0xD3, 0x40, 0x3E, 0x0A, 0xD3, 0x41, 0x79, 0xD3, 0x40, 0x06, 0x01, 0xCD, 0xF5, 0x00, 0x30, 0xDF, 0xCD, 0xBA, 0x00, 0xF1, 0xE2, 0xAE, 0x00, 0xFB, 0x37, 0xC9, 0xCD, 0xBA, 0x00, 0xF1, 0xE2, 0xB8, 0x00, 0xFB, 0xB7, 0xC9, 0x06, 0x08, 0x78, 0xD3, 0x41, 0xAF, 0xD3, 0x40, 0x04, 0x78, 0xFE, 0x0B, 0x20, 0xF4, 0x3E, 0x0E, 0xD3, 0x41, 0x3A, 0x00, 0x00, 0xD3, 0x40, 0x3E, 0x0F, 0xD3, 0x41, 0xC9, 0xF5, 0x3E, 0x0E, 0xD3, 0x41, 0x3E, 0x40, 0xD3, 0x40, 0x3E, 0x0F, 0xD3, 0x41, 0xDB, 0x40, 0xE6, 0x04, 0x20, 0xFA, 0xF1, 0xD3, 0x80, 0x3E, 0x0E, 0xD3, 0x41, 0x3E, 0x80, 0xD3, 0x40, 0xC9, 0xE5, 0x3E, 0x0F, 0xD3, 0x41, 0x21, 0x00, 0x00, 0xDB, 0x40, 0xE6, 0x02, 0x28, 0x0A, 0x2B, 0x7C, 0xB5, 0x20, 0xF5, 0x10, 0xF0, 0xE1, 0x37, 0xC9, 0xDB, 0x80, 0xE1, 0xB7, 0xC9, 0x00};
static const int AMY_TTS_REL[] = {4, 34, 41, 66, 74, 79, 84, 96, 104, 109, 114, 129, 162, 167, 171, 177, 181, -1};
#define AMY_TTS_MASK 205
#define AMY_TTS_OK 274
// Text to speech for Amy Studio speech (-speech FILE; the web page's speech boxes). A phrase is a list of
// (clip, speeds) entries ending in 0 that the list player gets in HL; a clip is one recording (a word or
// part of one). A text for a phrase list's address or a clip's address is spoken by the adapter's text to
// speech instead (amytts\amytts.asm), when the adapter can (Windows); "-" skips it. The rest keep their
// samples. Phrase texts work when the game passes the list from ROM (Amy Chess, the Space Taxi demo); a game
// that builds its lists in RAM (Solar System) needs clip texts (the web page adds them: the phrase's text on
// its first clip, "-" on the others, when no other phrase uses those clips).
// The routine, the table (dw address, dw text; 0 ends) and the texts go in the loader's free space if they
// fit, else after the ROM (up to 32K). Hooks (kind): 2 = a list player's PUSH IX / PUSH IY at its entry
// (HL = the list) -> CALL CLIP, spoken: tones back on (mixer $78), RET; 1 = its LD B,(IX+0) / LD C,(IX+1)
// for each clip (HL = the clip) -> CALL CLIP, spoken: the next list entry; 0 = a single-clip player's
// PUSH HL / CALL setup (HL = the clip) -> CALL CLIP, spoken: mixer $78, RET.
// Phrase tables (Solar System): PUSH IX / ADD A,A / LD E,A / LD D,0 / LD HL,table / ADD HL,DE / LD E,(HL) /
// INC HL / LD D,(HL) / PUSH DE / POP IX speaks phrase A: its entries (clip, speeds; 0 ends) are groups, a
// ZX0-packed clip (unpacked to RAM) and the plain clips after it with bit 7 of the speed set; each group is
// copied to a RAM list for the list player. Hook 3: CALL CLIP with HL = the phrase's address from the table,
// spoken: mixer $78, RET; else PUSH IX / ADD A,A and on.
typedef struct { int kind, site, loop, setup; } AmyHook;   // (kind 3: setup = the table)
static AmyHook amy_hooks[8];
static int amy_nhooks = 0;
static int amy_nspeech = 0;                     // -speech: the phrase / clip addresses and their texts (sorted)
static int amy_speech_clip[256];
static char amy_speech_text[256][256];
static size_t amy_rom_len = 0;                  // the ROM's length after amy_tts (the block after the ROM)

// The phrases: lists of entries (clip >= 8000H, speeds 1-60H each) up to a 0 word, each clip's data ending in
// FFH (FEH takes 2 more bytes), not the tail of a longer list, and with the list's address somewhere in the
// ROM as LD HL,list. For the log (the addresses -speech takes).
static int amy_clip_len(const uint8_t* rom, size_t n, int p) {
    int i = p - 0x8000, k = 0;
    if (i < 0 || i >= (int)n) return 0;
    while (i < (int)n && k < 0x3000) {
        if (rom[i] == 0xFF) return k + 1;
        int s = rom[i] == 0xFE ? 3 : 1;
        i += s; k += s;
    }
    return 0;
}

static int amy_entry(const uint8_t* rom, size_t n, long j) {              // a list entry's clip, or 0
    if (j < 0 || j + 4 > (long)n) return 0;
    int p = rom[j] | rom[j + 1] << 8;
    return p >= 0x8000 && rom[j + 2] >= 1 && rom[j + 2] <= 0x60 && rom[j + 3] >= 1 && rom[j + 3] <= 0x60 && amy_clip_len(rom, n, p) ? p : 0;
}

static void amy_phrase_log(const uint8_t* rom, size_t n) {
    int np = 0;
    for (size_t i = 0; i + 6 < n; i++) {
        if (amy_entry(rom, n, (long)i - 4)) continue;                       // inside a longer list
        size_t j = i;
        int ng = 0, ok = 1;
        while (j + 4 <= n && (rom[j] | rom[j + 1] << 8)) {
            if (!amy_entry(rom, n, (long)j) || ng == 64) { ok = 0; break; }
            ng++; j += 4;
        }
        if (!ok || !ng || j + 2 > n) continue;
        int a = 0x8000 + (int)i, used = 0;                                 // LD HL,list somewhere
        for (size_t k = 0; k + 2 < n && !used; k++) used = rom[k] == 0x21 && rom[k + 1] == (a & 0xFF) && rom[k + 2] == (a >> 8);
        if (!used) continue;
        printf("%s %04X:", np++ ? ";" : "\n    Speech phrases (list: clips, for -speech):", a);
        for (size_t k = i; k < j; k += 4) printf(" %04X", rom[k] | rom[k + 1] << 8);
    }
}

static void amy_tts(uint8_t* rom, size_t rom_len, Gap* gap) {
    amy_rom_len = 0;
    if (!amy_nhooks || !amy_nspeech || !gap) return;
    int mask = -1;                                                          // the loader's current_interrupt_mask:
    for (int i = 0; i + 6 <= gap->info_off; i++)                            // LD HL,mask / LD B,(HL) / OR B / LD (HL),A
        if (gap->stub[i] == 0x21 && gap->stub[i + 3] == 0x46 && gap->stub[i + 4] == 0xB0 && gap->stub[i + 5] == 0x77) {
            mask = gap->stub[i + 1] | gap->stub[i + 2] << 8; break;
        }
    if (mask < 0) { printf("\n    Speech texts: the loader's interrupt mask not found, left out"); return; }
    int size = (int)sizeof AMY_TTS + 4 * amy_nspeech + 2;
    for (int h = 0; h < amy_nhooks; h++) size += amy_hooks[h].kind == 3 ? 39 : 21;
    for (int k = 0; k < amy_nspeech; k++) size += 1 + (strcmp(amy_speech_text[k], "-") ? (int)strlen(amy_speech_text[k]) : 0);
    int base, in_gap = gap->next + size <= gap->end;
    if (in_gap) base = gap->next;
    else if (rom_len + size <= MAX_ROM_SIZE) base = 0x8000 + (int)rom_len;
    else { printf("\n    Speech texts: no room (%d bytes)!", size); return; }
    uint8_t* c = calloc(size, 1);
    memcpy(c, AMY_TTS, sizeof AMY_TTS);
    for (const int* r = AMY_TTS_REL; *r >= 0; r++) { int w = (c[*r] | c[*r + 1] << 8) + base; c[*r] = w & 0xFF; c[*r + 1] = w >> 8; }
    c[AMY_TTS_MASK] = mask & 0xFF; c[AMY_TTS_MASK + 1] = mask >> 8;
    int t = (int)sizeof AMY_TTS, x = t + 4 * amy_nspeech + 2;             // the table, then the texts
    for (int k = 0; k < amy_nspeech; k++) {
        const char* s = amy_speech_text[k];
        int len = strcmp(s, "-") ? (int)strlen(s) : 0;
        c[t++] = amy_speech_clip[k] & 0xFF; c[t++] = amy_speech_clip[k] >> 8;
        c[t++] = (base + x) & 0xFF; c[t++] = (base + x) >> 8;
        c[x++] = (uint8_t)len; memcpy(&c[x], s, len); x += len;
    }
    t += 2;                                                                 // (the 0 word)
    for (int h = 0; h < amy_nhooks; h++) {
        const AmyHook* k = &amy_hooks[h];
        int hk = base + x, site = k->site + 0x8000;
        c[x++] = 0xCD; c[x++] = base & 0xFF; c[x++] = base >> 8;             // CALL CLIP
        if (k->kind == 1) {
            c[x++] = 0x38; c[x++] = 9;                                      // JR C,spoken
            c[x++] = 0xDD; c[x++] = 0x46; c[x++] = 0x00; c[x++] = 0xDD; c[x++] = 0x4E; c[x++] = 0x01;   // LD B,(IX+0) / LD C,(IX+1)
            c[x++] = 0xC3; c[x++] = (site + 6) & 0xFF; c[x++] = (site + 6) >> 8;
            c[x++] = 0xDD; c[x++] = 0x23; c[x++] = 0xDD; c[x++] = 0x23;     // spoken: INC IX x2 / JP the next entry
            c[x++] = 0xC3; c[x++] = k->loop & 0xFF; c[x++] = k->loop >> 8;
            printf("\n    [0x%04X] Speech list player: clips with texts spoken (0x%04X)", (uint32_t)k->site, hk);
        } else if (k->kind == 3) {
            const uint8_t p1[7] = {0xF5, 0xE5, 0xD5, 0x6F, 0x26, 0x00, 0x29};  // PUSH AF/HL/DE / LD L,A / LD H,0 / ADD HL,HL
            x -= 3;                                                           // (the CALL goes after the lookup)
            memcpy(&c[x], p1, 7); x += 7;
            c[x++] = 0x11; c[x++] = k->setup & 0xFF; c[x++] = k->setup >> 8;   // LD DE,table
            const uint8_t p2[6] = {0x19, 0x5E, 0x23, 0x56, 0xEB, 0xCD};      // ADD HL,DE / LD E,(HL) / INC HL / LD D,(HL) / EX DE,HL / CALL CLIP
            memcpy(&c[x], p2, 6); x += 6;
            c[x++] = base & 0xFF; c[x++] = base >> 8;
            const uint8_t p3[7] = {0xD1, 0xE1, 0x38, 0x07, 0xF1, 0xDD, 0xE5};  // POP DE / POP HL / JR C,spoken / POP AF / PUSH IX
            memcpy(&c[x], p3, 7); x += 7;
            c[x++] = 0x87; c[x++] = 0xC3; c[x++] = (site + 3) & 0xFF; c[x++] = (site + 3) >> 8;   // ADD A,A / JP on
            const uint8_t done[10] = {0xF1, 0x3E, 0x07, 0xD3, 0x41, 0x3E, 0x78, 0xD3, 0x40, 0xC9};   // spoken: POP AF / mixer $78 / RET
            memcpy(&c[x], done, 10); x += 10;
            printf("\n    [0x%04X] Speech phrase table player: phrases with texts spoken (0x%04X)", (uint32_t)k->site, hk);
        } else if (k->kind == 2) {
            c[x++] = 0x38; c[x++] = 7;                                      // JR C,spoken
            c[x++] = 0xDD; c[x++] = 0xE5; c[x++] = 0xFD; c[x++] = 0xE5;     // PUSH IX / PUSH IY
            c[x++] = 0xC3; c[x++] = (site + 4) & 0xFF; c[x++] = (site + 4) >> 8;
            const uint8_t done[9] = {0x3E, 0x07, 0xD3, 0x41, 0x3E, 0x78, 0xD3, 0x40, 0xC9};   // spoken: mixer $78 / RET
            memcpy(&c[x], done, 9); x += 9;
            printf("\n    [0x%04X] Speech list player: phrases with texts spoken (0x%04X)", (uint32_t)k->site, hk);
        } else {
            c[x++] = 0x38; c[x++] = 7;                                      // JR C,spoken
            c[x++] = 0xE5; c[x++] = 0xCD; c[x++] = k->setup & 0xFF; c[x++] = k->setup >> 8;   // PUSH HL / CALL setup
            c[x++] = 0xC3; c[x++] = (site + 4) & 0xFF; c[x++] = (site + 4) >> 8;
            const uint8_t done[9] = {0x3E, 0x07, 0xD3, 0x41, 0x3E, 0x78, 0xD3, 0x40, 0xC9};   // spoken: mixer $78 / RET
            memcpy(&c[x], done, 9); x += 9;
            printf("\n    [0x%04X] Speech clip player: clips with texts spoken (0x%04X)", (uint32_t)k->site, hk);
        }
        rom[k->site] = 0xC3; rom[k->site + 1] = hk & 0xFF; rom[k->site + 2] = hk >> 8;
    }
    if (in_gap) { memcpy(&gap->stub[gap_off(gap, gap->next)], c, size); gap->next += size; }
    else { memcpy(&rom[rom_len], c, size); amy_rom_len = rom_len + size; }
    printf("\n    Speech texts: %d, text to speech at 0x%04X (%s, %d bytes)", amy_nspeech, base,
           in_gap ? "loader free space" : "after the ROM", size);
    free(c);
}

static const int SN_AMP[16] = {10000, 7943, 6310, 5012, 3981, 3162, 2512, 1995, 1585, 1259, 1000, 794, 631, 501, 398, 0};
static const int AY_AMP[16] = {0, 100, 145, 211, 307, 455, 645, 1074, 1266, 2050, 2922, 3728, 4925, 6353, 8056, 10000};

static int amy_triple(const uint8_t* t) { return (t[0] & 0xF0) == 0x90 && (t[1] & 0xF0) == 0xB0 && (t[2] & 0xF0) == 0xD0; }

static void amy_speech(uint8_t* rom, size_t n, const CodeMap* code, Gap* gap) {
    static const uint8_t loop[10] = {0x19, 0x06, 0x03, 0xED, 0xB3, 0x2B, 0x2B, 0x2B, 0x3D, 0x28};
    static const uint8_t setup[23] = {0x01, 0x81, 0x03, 0x79, 0xD3, 0xFF, 0xC6, 0x20, 0x4F, 0xAF, 0xD3, 0xFF, 0x10, 0xF5,
                                      0x3E, 0xE7, 0xD3, 0xFF, 0x3E, 0xFF, 0xD3, 0xFF, 0xC9};
    static const uint8_t quiet[12] = {0x3E, 0x9F, 0xD3, 0xFF, 0x3E, 0xBF, 0xD3, 0xFF, 0x3E, 0xDF, 0xD3, 0xFF};
    static const uint8_t out_c[23] = {0xF5, 0x0E, 0x40,                    // PUSH AF / LD C,$40
                                      0x3E, 0x08, 0xD3, 0x41, 0xED, 0xA3,  // LD A,8 / OUT ($41),A / OUTI
                                      0x3E, 0x09, 0xD3, 0x41, 0xED, 0xA3,
                                      0x3E, 0x0A, 0xD3, 0x41, 0xED, 0xA3,
                                      0xF1, 0xC9};                         // POP AF / RET
    static const uint8_t on_c[11] = {0x3E, 0x07, 0xD3, 0x41, 0x3E, 0x7F, 0xD3, 0x40, 0x3E, 0xFF, 0xC9};   // mixer $7F / LD A,$FF
    static const uint8_t off_c[19] = {0x3E, 0x07, 0xD3, 0x41, 0x3E, 0x78, 0xD3, 0x40,                      // mixer $78
                                      0x3E, 0x08, 0xD3, 0x41, 0x3E, 0x00, 0xD3, 0x40, 0x3E, 0x9F, 0xC9};  // volume A 0 / LD A,$9F
    static const uint8_t iy_c[12] = {0xC5, 0x04, 0x04, 0x04, 0x0C, 0x0C, 0x0C,   // PUSH BC / INC B x3 / INC C x3
                                     0xC5, 0xFD, 0xE1, 0xC1, 0xC9};        // PUSH BC / POP IY / POP BC / RET
    amy_nhooks = 0;
    if (!gap || !gap->next) return;
    int out = 0, tables[8], ntables = 0, header = 0;
    #define AMY_PUT(var, c) do { var = gap->next; memcpy(&gap->stub[gap_off(gap, gap->next)], c, sizeof c); gap->next += sizeof c; } while (0)
    for (size_t i = 0; i + 16 <= n; i++) {
        if (memcmp(&rom[i], loop, sizeof loop) || rom[i + 11] != 0xCD || rom[i + 14] != 0x18 || rom[i + 15] != 0xF0) continue;
        if (!header) { printf("\n  Amy Studio speech:"); header = 1; }
        int d = (rom[i + 12] | rom[i + 13] << 8) - 0x8000, s = -1, m = -1, setter = -1;
        for (int k = (int)i - 7; k >= 0 && k >= (int)i - 0x60; k--)    // EXX / LD HL,level / LD D,0 / EXX
            if (rom[k] == 0xD9 && rom[k + 1] == 0x21 && rom[k + 4] == 0x16 && rom[k + 5] == 0x00 && rom[k + 6] == 0xD9) { s = k; break; }
        if (s >= 0) m = (rom[s + 2] | rom[s + 3] << 8) - 0x8000;
        int done = 0;
        for (int k = 0; k < ntables; k++) done |= tables[k] == m;
        int fixed = d >= 0 && d + 9 <= (int)n && rom[d] == 0xC5 && rom[d + 1] == 0x06 && rom[d + 3] == 0x00 && rom[d + 4] == 0x10 && rom[d + 5] == 0xFD;
        int iy = d >= 0 && d + 9 <= (int)n && rom[d] == 0xC5 && rom[d + 1] == 0xFD && rom[d + 2] == 0xE5 && rom[d + 3] == 0xC1 &&
                 rom[d + 4] == 0x00 && rom[d + 5] == 0x10 && rom[d + 6] == 0xFD;
        if (iy) for (int k = s - 3; k >= 0 && k >= s - 0x40; k--) if (rom[k] == 0xC5 && rom[k + 1] == 0xFD && rom[k + 2] == 0xE1) { setter = k; break; }
        if (m < 0 || m + 3 > (int)n || (!done && !amy_triple(&rom[m])) || !(fixed || setter >= 0)) {
            printf("\n    [0x%04X] Speech loop not recognised, left as it is", (uint32_t)i); continue;
        }
        if (amy_nhooks < 8 && s >= 5 && rom[s - 5] == 0xE5 && rom[s - 4] == 0xCD && rom[s - 1] == 0xE1)       // PUSH HL / CALL setup / POP HL
            amy_hooks[amy_nhooks++] = (AmyHook){0, s - 5, 0, rom[s - 3] | rom[s - 2] << 8};
        else if (amy_nhooks < 8 && s + 12 <= (int)n && rom[s + 7] == 0x7E && rom[s + 8] == 0xFE && rom[s + 9] == 0xFF && rom[s + 10] == 0x28)
            for (int k = s - 6; k >= 0 && k >= s - 0x40; k--)              // LD B,(IX+0) / LD C,(IX+1) / PUSH BC / POP IY
                if (rom[k] == 0xDD && rom[k + 1] == 0x46 && rom[k + 2] == 0x00 && rom[k + 3] == 0xDD && rom[k + 4] == 0x4E &&
                    rom[k + 5] == 0x01 && rom[k + 6] == 0xC5 && rom[k + 7] == 0xFD && rom[k + 8] == 0xE1) {
                    amy_hooks[amy_nhooks++] = (AmyHook){1, k, 0x8000 + s + 12 + (int8_t)rom[s + 11], 0};
                    for (int e = k - 6; amy_nhooks < 8 && e >= 0 && e >= s - 0x60; e--)   // the entry: PUSH IX / PUSH IY / PUSH HL / CALL
                        if (rom[e] == 0xDD && rom[e + 1] == 0xE5 && rom[e + 2] == 0xFD && rom[e + 3] == 0xE5 && rom[e + 4] == 0xE5 && rom[e + 5] == 0xCD) {
                            amy_hooks[amy_nhooks++] = (AmyHook){2, e, 0, 0}; break;
                        }
                    break;
                }
        int need = (out ? 0 : 23 + 11 + 19) + (setter >= 0 ? 12 : 0);
        if (gap->next + need > gap->end) { printf("\n    [0x%04X] Speech: no room!", (uint32_t)i); return; }
        if (!out) {
            AMY_PUT(out, out_c);
            int on, off;
            AMY_PUT(on, on_c); AMY_PUT(off, off_c);
            for (size_t k = 0; k + sizeof setup <= n; k++)
                if (!memcmp(&rom[k], setup, sizeof setup)) {
                    printf("\n    [0x%04X] Speech tone setup: AY tones off (0x%04X)", (uint32_t)k, on);
                    rom[k + 18] = 0xCD; rom[k + 19] = on & 0xFF; rom[k + 20] = on >> 8; rom[k + 21] = 0x00;
                }
            for (size_t k = 0; k + sizeof quiet <= n; k++)
                if (!memcmp(&rom[k], quiet, sizeof quiet)) {
                    printf("\n    [0x%04X] Sound off: AY tones back on (0x%04X)", (uint32_t)k, off);
                    rom[k] = 0xCD; rom[k + 1] = off & 0xFF; rom[k + 2] = off >> 8; rom[k + 3] = 0x00;
                }
        }
        rom[i + 1] = 0xCD; rom[i + 2] = out & 0xFF; rom[i + 3] = out >> 8; rom[i + 4] = 0x00;   // CALL out / NOP
        if (!done) {
            int t0 = m, t1 = m + 3;
            while (t0 >= 3 && amy_triple(&rom[t0 - 3])) t0 -= 3;
            while (t1 + 3 <= (int)n && amy_triple(&rom[t1])) t1 += 3;
            for (int t = t0; t < t1; t += 3) {
                int want = SN_AMP[rom[t] & 15] + SN_AMP[rom[t + 1] & 15] + SN_AMP[rom[t + 2] & 15], best = -1, ba = 0, bb = 0, bc = 0;
                for (int a = 15; a >= 0; a--)
                    for (int b = a; b >= 0; b--)
                        for (int c = b; c >= 0; c--) {
                            int e = AY_AMP[a] + AY_AMP[b] + AY_AMP[c] - want;
                            if (e < 0) e = -e;
                            if (best < 0 || e < best) { best = e; ba = a; bb = b; bc = c; }
                        }
                rom[t] = (uint8_t)ba; rom[t + 1] = (uint8_t)bb; rom[t + 2] = (uint8_t)bc;
            }
            if (ntables < 8) tables[ntables++] = m;
            printf("\n    [0x%04X] Speech levels: %d, for the AY", (uint32_t)t0, (t1 - t0) / 3);
        }
        if (fixed) {
            int b = rom[d + 2];
            if (b && b < 253) rom[d + 2] = (uint8_t)(b + 3);
            printf("\n    [0x%04X] Speech loop: AY volumes direct (0x%04X), delay 0x%04X: %d loops, was %d", (uint32_t)i, out, d, rom[d + 2], b);
        } else {
            int fix;
            AMY_PUT(fix, iy_c);
            rom[setter] = 0xCD; rom[setter + 1] = fix & 0xFF; rom[setter + 2] = fix >> 8;
            printf("\n    [0x%04X] Speech loop: AY volumes direct (0x%04X), delays set at 0x%04X: 3 loops more (0x%04X)", (uint32_t)i, out, setter, fix);
        }
    }
    #undef AMY_PUT
    for (size_t i = 0; amy_nhooks && amy_nhooks < 8 && i + 16 <= n; i++) {   // phrase tables (see AmyHook)
        if (rom[i] != 0xDD || rom[i + 1] != 0xE5 || rom[i + 2] != 0x87 || rom[i + 3] != 0x5F || rom[i + 4] != 0x16 || rom[i + 5] != 0x00 ||
            rom[i + 6] != 0x21 || rom[i + 9] != 0x19 || rom[i + 10] != 0x5E || rom[i + 11] != 0x23 || rom[i + 12] != 0x56 ||
            rom[i + 13] != 0xD5 || rom[i + 14] != 0xDD || rom[i + 15] != 0xE1) continue;
        int t = rom[i + 7] | rom[i + 8] << 8, o = t - 0x8000;
        if (o < 0 || o + 2 > (int)n) continue;
        int np = ((rom[o] | rom[o + 1] << 8) - t) / 2;                     // (the first phrase follows the table)
        if (np < 1 || np > 64 || o + 2 * np > (int)n) continue;
        amy_hooks[amy_nhooks++] = (AmyHook){3, (int)i, 0, t};
        printf("\n    [0x%04X] Speech phrase table 0x%04X, %d phrases (A = 0 up; for -speech):", (uint32_t)i, t, np);
        for (int k = 0; k < np; k++) printf(" %04X", rom[o + 2 * k] | rom[o + 2 * k + 1] << 8);
    }
    if (header) amy_phrase_log(rom, n);
}

void apply_auto_patches(uint8_t* rom, size_t rom_len, int swap_joy, int smart_ports, Gap* gap) {
    CodeMap* code = trace_code(rom, rom_len);
    uint8_t* orig = malloc(rom_len); memcpy(orig, rom, rom_len);
    amy_speech(rom, rom_len, code, gap);
    inir_addressed(rom, rom_len, gap);

    static Vector vecs[8];
    int nv = 0, reads_fc = 0;
    collect_patches(rom, rom_len, code, smart_ports, gap, vecs, &nv, &reads_fc);
    const VectorPatch* snd = &vec_patches[0];
    int ks = 0;
    while (ks < nv && vecs[ks].slot != snd->vector_offset) ks++;
    if (gap && gap->next) {
        uint8_t* found = calloc(rom_len, 1);
        sound_via_c(rom, rom_len, code, found);
        int sound = snd->vector_data[1] | (snd->vector_data[2] << 8), nops = 0, size = 0;
        uint8_t ops[16], bodies[16][32];
        int blen[16], thunks[16];
        for (size_t i = 0; i < rom_len; i++) {                               // one thunk per instruction, in order of first site
            if (!found[i]) continue;
            int k = 0;
            while (k < nops && ops[k] != found[i]) k++;
            if (k == nops) { ops[nops] = found[i]; blen[nops] = sound_c_thunk(bodies[nops], found[i], sound); size += blen[nops++]; }
        }
        size += 12 + 10 * nops;
        if (nops && gap->next + size > gap->end) printf("\n    Sound via OUT (C) - no room!");
        else if (nops) {
            static uint8_t h[256];
            for (int k = 0; k < nops; k++) {
                thunks[k] = gap->next;
                memcpy(&gap->stub[gap_off(gap, gap->next)], bodies[k], blen[k]);
                gap->next += blen[k];
            }
            int hlen = sound_c_handler(h, gap->next, ops, thunks, nops, sound);
            memcpy(&gap->stub[gap_off(gap, gap->next)], h, hlen);
            if (ks == nv) { vecs[ks].slot = snd->vector_offset; memcpy(vecs[ks].data, snd->vector_data, 3); vecs[ks].desc = "Sound (RST 0x30)"; vecs[ks].nsites = 0; nv++; }
            for (size_t i = 0; i < rom_len; i++) {
                if (!found[i]) continue;
                uint8_t op2 = found[i];
                if (op2 == 0xA3 || op2 == 0xAB || op2 == 0xB3 || op2 == 0xBB)
                    printf("\n    [0x%04X] Sound via %s (RST 0x30)", (uint32_t)i,
                           op2 == 0xA3 ? "OUTI" : op2 == 0xAB ? "OUTD" : op2 == 0xB3 ? "OTIR" : "OTDR");
                else printf("\n    [0x%04X] Sound via OUT (C),%c (RST 0x30)", (uint32_t)i, "BCDEHL?A"[(op2 >> 3) & 7]);
                rom[i] = 0xF7;                                              // RST $30 / op2
                if (vecs[ks].nsites < 1024) vecs[ks].sites[vecs[ks].nsites++] = (int)i;
            }
            static char sdesc[96];
            snprintf(sdesc, sizeof sdesc, "%s (OUT (C) sites: handler at 0x%04X)", vecs[ks].desc, gap->next);
            vecs[ks].desc = sdesc;
            vecs[ks].data[0] = 0xC3; vecs[ks].data[1] = gap->next & 0xFF; vecs[ks].data[2] = gap->next >> 8;
            gap->next += hlen;
        }
        free(found);
    }
    // -xbanks: each extra C000 half, converted behind the original fixed bank
    if (nxbanks) {
        if (rom_len != 2 * 0x4000) printf("\n  -xbanks: needs a 32KB image (fixed bank + one bank), ignored");
        else {
            free(xbanks_out); xbanks_out = malloc((size_t)nxbanks * 0x4000);
            for (int b = 0; b < nxbanks; b++) {
                uint8_t* img = malloc(rom_len);
                memcpy(img, orig, 0x4000); memcpy(img + 0x4000, xbanks + (size_t)b * 0x4000, 0x4000);
                CodeMap* xc = trace_code(img, rom_len);
                int id = xbank_mega ? xbank_ids[b] : b;
                printf("\n  %s bank %d:", xbank_mega ? "Code" : "Extra", id);
                cur_bank_known = NULL; known_fixed_only = 1;
                if (xbank_mega)
                    for (size_t k = 0; k < sizeof known_bank_data / sizeof known_bank_data[0]; k++)
                        if (known_bank_data[k].crc == xbank_crc && known_bank_data[k].bank == id) cur_bank_known = known_bank_data[k].offsets;
                collect_patches(img, rom_len, xc, smart_ports, gap, vecs, &nv, &reads_fc);
                if (xbank_mega) i_register(img, rom_len, xc, gap, 0x4000);
                cur_bank_known = NULL; known_fixed_only = 0;
                uint8_t* found = calloc(rom_len, 1);
                sound_via_c(img, rom_len, xc, found);
                for (size_t i = 0; i < rom_len; i++)
                    if (found[i]) { printf("\n    [0x%04X] WARNING: sound via OUT (C) in %s bank: not converted", (uint32_t)i, xbank_mega ? "a code" : "an extra"); break; }
                free(found);
                int merged = 0, clash = 0;
                for (size_t i = 0; i < 0x4000; i++) {
                    if (img[i] == orig[i]) continue;
                    if (rom[i] == orig[i]) { rom[i] = img[i]; merged++; }
                    else if (rom[i] != img[i]) { clash++; printf("\n    [0x%04X] WARNING: fixed bank patched differently for %s bank %d", (uint32_t)i, xbank_mega ? "code" : "extra", id); }
                }
                printf("\n    fixed bank: %d more bytes patched for this bank%s", merged, clash ? " (with clashes)" : "");
                memcpy(xbanks_out + (size_t)b * 0x4000, img + 0x4000, 0x4000);
                free_code(xc); free(img);
            }
            ks = 0;
            while (ks < nv && vecs[ks].slot != snd->vector_offset) ks++;
        }
    }
    // The loader reads NABU controller 1 for port FF and controller 2 for port FC. On a ColecoVision,
    // FC is controller 1, so a game that reads FC directly expects player 1 there: swap them
    // (auto = 2), unless forced on (1) / off (0). The loader does the swap (loader_options bit 1).
    int swap = swap_joy == 2 ? reads_fc : swap_joy;
    if (swap_joy == 2 && swap) printf("\n  Joystick ports swapped (auto: game reads controller 1 port FC)");
    if (swap && gap) gap->option_bits |= LOADER_OPT_SWAP_PORTS;
    install_vectors(rom, rom_len, orig, vecs, nv, gap);
    if (code->nmi_uses_ei || code->nmi_reads_iff) wrap_nmi(rom, rom_len, gap, code->nmi_reads_iff);
    protect_rom(rom, rom_len, orig, code, gap, calculate_crc16(orig, rom_len));
    idle_restart_ei(rom, rom_len, code, gap);
    sp_trick_di(rom, rom_len, code, gap);
    i_register(rom, rom_len, code, gap, 0);
    bios_entries(rom, rom_len, code);
    halt_di_ei(rom, rom_len);
    amy_tts(rom, rom_len, gap);
    free(orig);
    free_code(code);
}

// patches.z80: known titles' patches, by ROM CRC16, in the loader's patcher format (brijohn's
// patcher.z80). "patchset:" is a table of .word crc, .word label pairs; each label's directives
// assemble to a byte stream of entries: .word address (0 = end), .byte count, then count data bytes
// (written as .byte or .word, little-endian). Addresses are CPU addresses ($8000 = ROM offset 0).
// Returns 1 if the CRC is listed (its patches replace the automatic ones, even an empty list).
static char* patches_text = NULL;       // patches.z80, loaded by main (NULL: none)

static int directive(char* line, char** args) {         // 1 = .word, 2 = .byte, 0 = other; strips comments
    char* c = strchr(line, ';'); if (c) *c = 0;
    while (*line == ' ' || *line == '\t') line++;
    if (!strncmp(line, ".word", 5) && (line[5] == ' ' || line[5] == '\t')) { *args = line + 5; return 1; }
    if (!strncmp(line, ".byte", 5) && (line[5] == ' ' || line[5] == '\t')) { *args = line + 5; return 2; }
    return 0;
}

static int label_of(const char* line, char* out, size_t n) {   // "name:" at the start of a line
    size_t k = 0;
    while (line[k] && (isalnum((unsigned char)line[k]) || line[k] == '_') && k + 1 < n) { out[k] = line[k]; k++; }
    if (k == 0 || line[k] != ':' || isdigit((unsigned char)line[0])) return 0;
    out[k] = 0; return 1;
}

int apply_external_patches(uint8_t* rom, size_t rom_len, uint16_t target_crc) {
    if (!patches_text) return 0;
    char* text = strdup(patches_text);
    char cur[128] = "", target[128] = "";
    uint8_t* s = malloc(strlen(text) + 16);      // byte stream of the target's entries
    size_t sn = 0;
    int pending_crc = -1, found = 0;
    for (int pass = 0; pass < 2; pass++) {
        if (pass == 1) { if (!found) break; free(text); text = strdup(patches_text); cur[0] = 0; }
        for (char* line = strtok(text, "\r\n"); line; line = strtok(NULL, "\r\n")) {
            char name[128], *args;
            if (label_of(line, name, sizeof name)) { strcpy(cur, name); continue; }
            int d = directive(line, &args);
            if (!d) continue;
            // split args on commas by hand (strtok is busy with lines)
            char* p = args;
            while (*p) {
                while (*p == ' ' || *p == '\t' || *p == ',') p++;
                if (!*p) break;
                char tokbuf[128]; size_t k = 0;
                while (p[k] && p[k] != ',' && k + 1 < sizeof tokbuf) { tokbuf[k] = p[k]; k++; }
                p += k; tokbuf[k] = 0;
                while (k && (tokbuf[k - 1] == ' ' || tokbuf[k - 1] == '\t')) tokbuf[--k] = 0;
                int is_num = isdigit((unsigned char)tokbuf[0]);
                long v = is_num ? strtol(tokbuf, NULL, 0) : 0;
                if (pass == 0 && !strcmp(cur, "patchset") && d == 1) {
                    if (pending_crc < 0) { if (is_num) pending_crc = (int)v; }
                    else {
                        if (!found && pending_crc == target_crc && !is_num) { strcpy(target, tokbuf); found = 1; }
                        pending_crc = -1;
                    }
                } else if (pass == 1 && !strcmp(cur, target)) {
                    if (d == 2) s[sn++] = (uint8_t)v;
                    else { s[sn++] = (uint8_t)v; s[sn++] = (uint8_t)(v >> 8); }
                }
            }
        }
    }
    free(text);
    if (!found) { free(s); return 0; }
    printf("\n  [CRC MATCH]: %s", target);
    for (size_t p = 0; p + 2 < sn; ) {
        int addr = s[p] | (s[p + 1] << 8), n = s[p + 2];
        if (addr == 0) break;
        const uint8_t* data = &s[p + 3];
        int have = (int)(sn - (p + 3)) < n ? (int)(sn - (p + 3)) : n;
        p += 3 + n;
        long off = addr - 0x8000;
        if (off < 0 || (size_t)(off + have) > rom_len) { printf("\n    [0x%04X] outside the ROM, skipped", addr); continue; }
        memcpy(&rom[off], data, have);
        printf("\n    [0x%04X] %d byte%s:", (unsigned)off, have, have == 1 ? "" : "s");
        for (int k = 0; k < have; k++) printf(" %02x", data[k]);
    }
    free(s);
    return 1;
}

// Megacarts (64K / 128K / 256K: 4, 8 or 16 banks of 16KB, the header in the last bank) for the NABU's
// RomWBW option card and CVLOAD.COM. A megacart has its last bank fixed at 8000 and selects the bank at
// C000 on a read of FFC0-FFFF (bank = address & (NB-1)). The converter converts the fixed bank plus bank
// NB-2 like a 32KB cart, then turns each bank select into OUT (7Bh),page: CVLOAD puts bank k in card page
// 50 - NB + k. Output: NAME.NAB (the converted image) and NAME.COL (the cart), run with CVLOAD NAME.
// Bank select styles (as megaprep.py):
//   Prince of Persia: one routine LD C,A / LD B,0 / LD HL,FFFE / CP A / SBC HL,BC / LD A,(HL) / RET and
//     a startup LD A,(FFFE) - patched in place.
//   Opcode (Pac-Man Collection 2008): PUSH BC / OR F0 / LD C,A / LD B,FF / LD A,(BC) / POP BC / RET.
//   CVBasic (Sydney Hunter...): inline LD A,(FFxx), the runtime's restores LD L,A / LD H,FF / LD A,(HL),
//     LD E,A / LD D,FF / LD A,(DE) and LD C,A / LD B,FF / LD A,(BC) (Princess Quest), and a RAM variable
//     LD (V),HL / LD H,(HL) or LD A,(HL), read back by LD HL,(V) and the same - each becomes a CALL to
//     a page routine in the loader's free space; the C000 half goes back to bank NB-2's own bytes (CVBasic
//     banked code does no port I/O, so the converter's pattern patches there would only hit data).
// Banks whose own code does port I/O (Pac-Man Collection, Zombie Near) still need megaprep.py.
static const uint8_t mega_prince[] = {0x4F, 0x06, 0x00, 0x21, 0xFE, 0xFF, 0xBF, 0xED, 0x42, 0x7E, 0xC9};
static const uint8_t mega_prince_start[] = {0x31, 0x00, 0x74, 0x3A, 0xFE, 0xFF};
static const uint8_t mega_opcode[] = {0xC5, 0xF6, 0xF0, 0x4F, 0x06, 0xFF, 0x0A, 0xC1, 0xC9};

// Megacart banks whose own code does port I/O (VDP, sound, controllers), by the image's CRC16 (fixed bank
// + bank NB-2): converted at C000 with the fixed bank (one set of RST dispatchers, as -xbanks) and stored
// converted in NAME.COL. Bank NB-2 in the list keeps the image's converted C000 half.
// nmi_stack: the NMI handler runs on its own stack (Suite Macabre keeps a guard byte at 73C4 under its
// small stack and traps at 8FD9 when it changes; the NABU's frame interrupt adds to the game's stack).
typedef struct { uint16_t crc; int banks[8]; const char* name; int nmi_stack; } MegaCode;
static const MegaCode mega_code[] = {
    {0xC28A, {6, 0, 1, 2, 4, -1}, "Pac-Man Collection (Opcode 2008)", 0},   // game banks 0-2, menu 6, menu music player 4
    {0x96F7, {0, -1}, "Zombie Near (Nanochess)", 0},                        // bank 0 reads the controllers
    {0x9E42, {5, 14, -1}, "Suite Macabre (CollectorVision)", 1},            // room graphics 5, engine 14 (VDP, sound)
};

// The cart's NMI vector (8021: JP nn) -> LD (save),SP / LD SP,stack / CALL nn / LD SP,(save) / RET, with a
// 96-byte stack, all in the loader's free space.
static void nmi_own_stack(uint8_t* rom, Gap* gap) {
    if (!gap || rom[0x21] != 0xC3) return;
    int at = gap->next, save = at, top = at + 2 + 96, w = top;
    if (at + 2 + 96 + 15 > gap->end) { printf("\n  NMI stack: no room!"); return; }
    int t = rom[0x22] | rom[0x23] << 8;
    const uint8_t c[15] = {0xED, 0x73, (uint8_t)save, (uint8_t)(save >> 8),          // LD (save),SP
                           0x31, (uint8_t)top, (uint8_t)(top >> 8),                   // LD SP,top
                           0xCD, (uint8_t)t, (uint8_t)(t >> 8),                       // CALL handler
                           0xED, 0x7B, (uint8_t)save, (uint8_t)(save >> 8),          // LD SP,(save)
                           0xC9};                                                     // RET
    memset(&gap->stub[gap_off(gap, at)], 0, 2 + 96);
    memcpy(&gap->stub[gap_off(gap, w)], c, 15);
    gap->next += 2 + 96 + 15;
    rom[0x22] = w & 0xFF; rom[0x23] = w >> 8;
    printf("\n  NMI handler 0x%04X on its own stack: wrapper at 0x%04X, stack 0x%04X-0x%04X", t, w, save + 2, top - 1);
}

// CVLOAD's 8.3 name for a megacart, from the file name: words of letters and digits, leaving out (...)
// and [...] and words that are only a number or a version (2012, v1, 00); each word gets its first
// letter, then the rest of the 8 go to the words in order: Sydney_Hunter -> SYDNEYHU, Sydney Hunter
// Sacred Tribe -> SYDNEHST, Princess Quest (2012) -> PRINCESQ.
static void mega_name(const char* bn, char* name) {
    char w[8][64]; int nw = 0, depth = 0, len = 0;
    char cur[64];
    for (const char* p = bn; ; p++) {
        int c = (unsigned char)*p;
        if (c == '(' || c == '[') depth++;
        if (!depth && c && isalnum(c)) { if (len < 63) cur[len++] = (char)toupper(c); continue; }
        if (len) {
            int numeric = 1;
            for (int k = (cur[0] == 'V' && len > 1) ? 1 : 0; k < len; k++) numeric &= isdigit((unsigned char)cur[k]) != 0;
            if (!numeric && nw < 8) { memcpy(w[nw], cur, len); w[nw][len] = 0; nw++; }
            len = 0;
        }
        if ((c == ')' || c == ']') && depth) depth--;
        if (!c) break;
    }
    int take[8] = {0}, left = 8;
    for (int k = 0; k < nw && left; k++) { take[k] = 1; left--; }
    for (int k = 0; k < nw && left; k++) {
        int more = (int)strlen(w[k]) - take[k];
        if (more > left) more = left;
        take[k] += more; left -= more;
    }
    int n = 0;
    for (int k = 0; k < nw; k++) { memcpy(name + n, w[k], take[k]); n += take[k]; }
    if (!n) name[n++] = 'M';
    name[n] = 0;
}

static int mega_find(const uint8_t* d, int lo, int hi, const uint8_t* p, int n, int from) {
    for (int i = from > lo ? from : lo; i + n <= hi; i++) if (!memcmp(&d[i], p, n)) return i;
    return -1;
}

// rom = the converted 32KB image (fixed bank at 0, bank NB-2 at 4000h), second = bank NB-2 as in the cart.
// Returns 0 if no bank switching was recognised.
static int megacart_banks(uint8_t* rom, const uint8_t* second, int nb, Gap* gap, int keep_c000) {
    const int B = 0x4000, mask = nb - 1, page0 = 50 - nb;
    int at = mega_find(rom, 0, B, mega_opcode, sizeof mega_opcode, 0);
    if (at >= 0) {                                              // A = bank: AND mask / ADD page0 / OUT (7Bh),A / RET
        const uint8_t r[9] = {0xE6, (uint8_t)mask, 0xC6, (uint8_t)page0, 0xD3, 0x7B, 0xC9, 0x00, 0x00};
        memcpy(&rom[at], r, 9);
        printf("\n    [0x%04X] Opcode-style bank routine -> OUT (7Bh),page", (uint32_t)at);
        return 1;
    }
    at = mega_find(rom, 0, B, mega_prince, sizeof mega_prince, 0);
    if (at >= 0) {                                              // C = FFFE - address: bank = (3E - C) & mask
        const uint8_t r[11] = {0x4F, 0x3E, (uint8_t)(0x3E & mask), 0x91, 0xE6, (uint8_t)mask, 0xC6, (uint8_t)page0, 0xD3, 0x7B, 0xC9};
        memcpy(&rom[at], r, 11);
        printf("\n    [0x%04X] Prince-style bank routine -> OUT (7Bh),page", (uint32_t)at);
        for (int s = 0; (s = mega_find(rom, 0, B, mega_prince_start, sizeof mega_prince_start, s)) >= 0; s++) {
            rom[s + 3] = rom[s + 4] = rom[s + 5] = 0;
            printf("\n    [0x%04X] startup LD A,(FFFE) removed", (uint32_t)(s + 3));
        }
        return 1;
    }
    // CVBasic: page routines in the loader's free space
    if (!gap || !gap->next) { printf("\n  Megacart: no loader free space for the page routines"); return 0; }
    int bvars[8], nv = 0;                                       // RAM variables holding the bank's FFxx address
    for (int i = 3; i < B && nv < 8; i++) {
        if ((rom[i] != 0x66 && rom[i] != 0x7E) || rom[i - 3] != 0x22) continue;
        int v = rom[i - 2] | rom[i - 1] << 8, dup = 0;
        if (v < 0x7000 || v >= 0x7400) continue;
        for (int k = 0; k < nv; k++) dup |= bvars[k] == v;
        const uint8_t rd[4] = {0x2A, (uint8_t)v, (uint8_t)(v >> 8), 0x66}, ra[4] = {0x2A, (uint8_t)v, (uint8_t)(v >> 8), 0x7E};
        if (!dup && (mega_find(rom, 0, B, rd, 4, 0) >= 0 || mega_find(rom, 0, B, ra, 4, 0) >= 0)) bvars[nv++] = v;
    }
    int need = nb * 5 + 3 * 12 + nv * 2 * 13;
    if (gap->next + need > gap->end) { printf("\n  Megacart: no room for the page routines!"); return 0; }
    uint8_t code[1024]; int n = 0, base = gap->next, sel[16];
    for (int k = 0; k < nb; k++) {                              // LD A,page / OUT (7Bh),A / RET
        sel[k] = base + n;
        code[n++] = 0x3E; code[n++] = (uint8_t)(page0 + k); code[n++] = 0xD3; code[n++] = 0x7B; code[n++] = 0xC9;
    }
    int sel_r[3];
    static const uint8_t r_lo[3] = {0x6F, 0x5F, 0x4F}, r_hi[3] = {0x26, 0x16, 0x06}, r_rd[3] = {0x7E, 0x1A, 0x0A};
    for (int k = 0; k < 3; k++) {                               // LD L,A / LD H,FF (or E / D, C / B), then the bank in A
        const uint8_t r[12] = {r_lo[k], r_hi[k], 0xFF, 0xF5, 0xE6, (uint8_t)mask, 0xC6, (uint8_t)page0, 0xD3, 0x7B, 0xF1, 0xC9};
        sel_r[k] = base + n; memcpy(&code[n], r, 12); n += 12;
    }
    int sel_v[8][2];
    for (int v = 0; v < nv; v++)
        for (int k = 0; k < 2; k++) {                           // LD (V),HL or LD HL,(V); then the bank in L
            const uint8_t op = k ? 0x2A : 0x22;
            const uint8_t r[13] = {op, (uint8_t)bvars[v], (uint8_t)(bvars[v] >> 8), 0xF5, 0x7D, 0xE6, (uint8_t)mask, 0xC6, (uint8_t)page0, 0xD3, 0x7B, 0xF1, 0xC9};
            sel_v[v][k] = base + n; memcpy(&code[n], r, 13); n += 13;
        }
    int found = 0;
    for (int i = 0; i + 2 < B; i++)
        if (rom[i] == 0x3A && rom[i + 2] == 0xFF && rom[i + 1] >= 0xC0) {
            int k = rom[i + 1] & mask;
            printf("\n    [0x%04X] LD A,($FF%02X) -> CALL bank %d", (uint32_t)i, rom[i + 1], k);
            rom[i] = 0xCD; rom[i + 1] = sel[k] & 0xFF; rom[i + 2] = sel[k] >> 8;
            found++;
        }
    for (int k = 0; k < 3; k++) {
        const uint8_t p[4] = {r_lo[k], r_hi[k], 0xFF, r_rd[k]};
        static const char* rn[3] = {"LD L,A/LD H,FF/LD A,(HL)", "LD E,A/LD D,FF/LD A,(DE)", "LD C,A/LD B,FF/LD A,(BC)"};
        for (int i = 0; (i = mega_find(rom, 0, B, p, 4, i)) >= 0; i++) {
            printf("\n    [0x%04X] %s -> CALL", (uint32_t)i, rn[k]);
            rom[i] = 0xCD; rom[i + 1] = sel_r[k] & 0xFF; rom[i + 2] = sel_r[k] >> 8; rom[i + 3] = 0x00;
            found++;
        }
    }
    for (int v = 0; v < nv; v++)
        for (int k = 0; k < 4; k++) {
            const uint8_t p[4] = {k & 1 ? 0x2A : 0x22, (uint8_t)bvars[v], (uint8_t)(bvars[v] >> 8), k & 2 ? 0x7E : 0x66};
            for (int i = 0; (i = mega_find(rom, 0, B, p, 4, i)) >= 0; i++) {
                printf("\n    [0x%04X] %s/%s -> CALL", (uint32_t)i, k & 1 ? "LD HL,(var)" : "LD (var),HL", k & 2 ? "LD A,(HL)" : "LD H,(HL)");
                rom[i] = 0xCD; rom[i + 1] = sel_v[v][k & 1] & 0xFF; rom[i + 2] = sel_v[v][k & 1] >> 8; rom[i + 3] = 0x00;
                found++;
            }
        }
    if (!found) return 0;
    memcpy(&gap->stub[gap_off(gap, base)], code, n);
    gap->next += n;
    printf("\n    Page routines at 0x%04X-0x%04X", base, base + n - 1);
    if (keep_c000) return 1;                                    // bank NB-2's code does I/O: stays converted
    int changed = 0;
    for (int i = 0; i < B; i++) changed += rom[B + i] != second[i];
    memcpy(&rom[B], second, B);
    printf("\n    Bank %d (C000 half) put back to its own bytes (%d had been patched)", nb - 2, changed);
    return 1;
}

// A VDP port kept in a RAM variable: LD A,$BE (or $BF) / LD (V),A, and somewhere (any bank of a
// megacart, or code the game copies to RAM) LD A,(V) / LD C,A shortly before an I/O-on-C instruction
// (Princess Quest: LD (7083),A at 812D; its RAM copy routine from bank 0 does OUTI with C = (7083)).
// The stored port becomes the NABU's.
static int c_io_soon(const uint8_t* d, size_t n, size_t i) {
    for (size_t k = i; k < i + 8 && k + 1 < n; k++)
        if (d[k] == 0xED && ((d[k + 1] & 0xC7) == 0x41 || (d[k + 1] & 0xC7) == 0x40 ||
                             ((d[k + 1] & 0xE4) == 0xA0 && (d[k + 1] & 3) >= 2))) return 1;
    return 0;
}
static void port_vars(uint8_t* rom, size_t rom_len, const uint8_t* all, size_t all_len) {
    for (size_t i = 0; i + 5 <= rom_len; i++) {
        if (rom[i] != 0x3E || (rom[i + 1] != 0xBE && rom[i + 1] != 0xBF) || rom[i + 2] != 0x32) continue;
        int v = rom[i + 3] | rom[i + 4] << 8, used = 0;
        if (v < 0x7000 || v >= 0x7400) continue;
        for (size_t k = 0; k + 4 <= all_len && !used; k++)
            if (all[k] == 0x3A && all[k + 1] == (v & 0xFF) && all[k + 2] == (v >> 8) && all[k + 3] == 0x4F && c_io_soon(all, all_len, k + 4)) used = 1;
        if (!used) continue;
        printf("\n    [0x%04X] LD A,$%02X / LD ($%04X),A: VDP port in a RAM variable (used with LD C,A) -> $%02X",
               (uint32_t)i, rom[i + 1], v, rom[i + 1] == 0xBE ? 0xA0 : 0xA1);
        rom[i + 1] = rom[i + 1] == 0xBE ? 0xA0 : 0xA1;
    }
}

// CVBasic games for the Super Game Module (Enchanted). Run on the cart before everything else (all banks of
// a megacart; nb = 0: a 32KB ROM). Found by CVBasic's SGM start-up: B = 0 / LD HL,2000 / LD (HL),H / INC H /
// JP P / LD H,20 / LD A,(HL) / CP H / JR NZ / INC H / JP P / JP found / ... OUT (53h),A.
//   * The SGM's RAM: the game's variables start at 2000, where the NABU has the loader. They move up by
//     4000h (to 6000-6FFF, below the BIOS RAM at 7000; CVBasic's own SGM variables at 7C00 stay). The code
//     of every bank is traced (a bank is entered by LD A,(FFxx) then a CALL/JP into C000-FFFF) and the
//     operands of LD A/HL/rr,(nn), LD (nn),A/HL/rr and the immediates LD rr,nn / LD IX,nn in the range move.
//     Immediates that are VRAM table bases (a multiple of 800h, e.g. the colour table 2000) or round
//     decimal constants (a multiple of 1000, e.g. 10000) stay, unless the next instructions use them as a
//     pointer. The SGM test is skipped (it writes 2000-7F00) and the start-up clear covers 6000-7FFF.
//   * The SGM's AY (50h latch, 51h write, 52h read) is the NABU's: OUT (50h),A -> RST 08 (the latch,
//     kept in a shadow), OUT (51h),A -> RST 38 (the write: register 7 keeps the NABU's port bits, 14/15
//     are left alone, the register is selected again with interrupts off) - as OUT (C),A after LD A,50h /
//     LD C,A or LD C,50h too. IN A,(52h) -> IN A,(40h). Other OUT (53h) -> NOPs.
static int sgm_off(int nb, size_t len, int bank, int a) {          // the cart offset of CPU address a, or -1
    if (a < 0x8000 || a > 0xFFFF) return -1;
    size_t o = !nb ? (size_t)(a - 0x8000) : a < 0xC000 ? (size_t)(nb - 1) * 0x4000 + (a - 0x8000) : (size_t)bank * 0x4000 + (a - 0xC000);
    return o < len ? (int)o : -1;
}
static int sgm_operand(const uint8_t* d, int* imm) {                // where a 16-bit address operand is, or 0
    uint8_t op = d[0];
    *imm = op == 0x01 || op == 0x11 || op == 0x21 || ((op == 0xDD || op == 0xFD) && d[1] == 0x21);
    if (op == 0x01 || op == 0x11 || op == 0x21 || op == 0x22 || op == 0x2A || op == 0x32 || op == 0x3A) return 1;
    if (op == 0xED && (d[1] & 0xC7) == 0x43 && d[1] != 0x73 && d[1] != 0x7B) return 2;   // (not SP)
    if ((op == 0xDD || op == 0xFD) && (d[1] == 0x21 || d[1] == 0x22 || d[1] == 0x2A)) return 2;
    return 0;
}
// An immediate that stays: a VRAM table base (multiple of 800h) or a round decimal constant, not used as a pointer.
static int sgm_keep(const uint8_t* cart, size_t len, size_t o, int v);
// True if the value loaded at cart[o] (LD HL,nn / LD DE,nn / LD BC,nn) is used as a pointer in the next
// few instructions (through ADD HL,rr and EX DE,HL).
static int sgm_deref(const uint8_t* cart, size_t len, size_t o) {
    int r = cart[o] == 0x21 ? 2 : cart[o] == 0x11 ? 1 : cart[o] == 0x01 ? 0 : -1;   // 0 BC, 1 DE, 2 HL
    if (r < 0) return 0;
    o += 3;
    for (int k = 0; k < 6 && o < len; k++) {
        uint8_t op = cart[o], op2 = o + 1 < len ? cart[o + 1] : 0;
        if (r == 2 && (op == 0x34 || op == 0x35 || op == 0x36 || op == 0x86 || op == 0x8E || op == 0x96 || op == 0x9E ||
                       op == 0xA6 || op == 0xAE || op == 0xB6 || op == 0xBE || ((op & 0xC0) == 0x40 && op != 0x76 && ((op & 7) == 6 || (op & 0x38) == 0x30)) ||
                       (op == 0xCB && (op2 & 7) == 6) || (op == 0xED && (op2 == 0xA0 || op2 == 0xB0)))) return 1;
        if (r == 1 && (op == 0x1A || op == 0x12 || (op == 0xED && (op2 == 0xA0 || op2 == 0xB0)))) return 1;
        if (r == 0 && (op == 0x0A || op == 0x02)) return 1;
        if (op == 0x09 + 0x10 * r) r = 2;                               // ADD HL,rr
        else if (op == 0xEB) r = r == 2 ? 1 : r == 1 ? 2 : r;           // EX DE,HL
        else if (op == 0xCD || op == 0xC3 || op == 0xC9 || op == 0x18 || op == 0xE9 || (op & 0xC7) == 0xC2 || (op & 0xE7) == 0x20) return 0;
        else if ((r == 2 && (op == 0x21 || op == 0x2A || op == 0xE1)) || (r == 1 && (op == 0x11 || op == 0xD1)) || (r == 0 && (op == 0x01 || op == 0xC1))) return 0;
        o += z80_len(cart, len, o);
    }
    return 0;
}
static int sgm_keep(const uint8_t* cart, size_t len, size_t o, int v) {
    return (v % 0x800 == 0 || v % 1000 == 0) && !sgm_deref(cart, len, o);
}
static void cvbasic_sgm(uint8_t* cart, size_t len, int nb, Gap* gap) {
    const size_t fix = nb ? (size_t)(nb - 1) * 0x4000 : 0, fixlen = nb ? 0x4000 : len;
    int test = -1, ok_to = 0;
    for (size_t i = fix; i + 32 <= fix + fixlen && test < 0; i++) {
        static const uint8_t t1[] = {0x06, 0x00, 0x21, 0x00, 0x20, 0x74, 0x24, 0xF2}, t2[] = {0x26, 0x20, 0x7E, 0xBC, 0x20, 0x07, 0x24, 0xF2};
        if (memcmp(&cart[i], t1, 8) || memcmp(&cart[i + 10], t2, 8) || cart[i + 20] != 0xC3) continue;
        int k = (int)i + 23;
        if (cart[k] != 0x3E || cart[k + 1] != 0x01 || cart[k + 2] != 0xD3 || cart[k + 3] != 0x53) continue;
        test = (int)i; ok_to = cart[i + 21] | cart[i + 22] << 8;
    }
    if (test < 0) return;
    printf("\n  CVBasic Super Game Module game (SGM test at 0x%04X):", (uint32_t)(test - fix + 0x8000));
    // trace
    uint8_t* seen = calloc(len, 1);
    int (*todo)[2] = malloc(sizeof(int[2]) * 65536); int nt = 0;
    uint8_t* queued = calloc(len, 1);
    #define SGM_ADD(bk, a) do { int o_ = sgm_off(nb, len, (bk), (a)); if (o_ >= 0 && !queued[o_] && nt < 65536) { queued[o_] = 1; todo[nt][0] = (bk); todo[nt][1] = (a); nt++; } } while (0)
    SGM_ADD(nb ? nb - 1 : 0, cart[fix + 10] | cart[fix + 11] << 8);
    for (int v = 0x0C; v < 0x24; v += 3) if (cart[fix + v] == 0xC3) SGM_ADD(nb ? nb - 1 : 0, cart[fix + v + 1] | cart[fix + v + 2] << 8);
    while (nt) {
        nt--; int bank = todo[nt][0], a = todo[nt][1];
        for (;;) {
            int o = sgm_off(nb, len, bank, a);
            if (o < 0 || seen[o]) break;
            int l = z80_len(cart, len, o);
            seen[o] = 1;
            uint8_t op = cart[o], b1 = o + 1 < (int)len ? cart[o + 1] : 0, b2 = o + 2 < (int)len ? cart[o + 2] : 0;
            int nn = b1 | b2 << 8, rel = a + 2 + (int8_t)b1;
            if (op == 0x3A && b2 == 0xFF && b1 >= 0xC0 && nb) bank = b1 & (nb - 1);   // LD A,(FFxx): bank select
            if (op == 0xC3) { SGM_ADD(bank, nn); break; }
            if (op == 0x18) { SGM_ADD(bank, rel); break; }
            if ((op & 0xC7) == 0xC2 || op == 0xCD || (op & 0xC7) == 0xC4) SGM_ADD(bank, nn);
            else if (op == 0x10 || (op & 0xE7) == 0x20) SGM_ADD(bank, rel);
            if (op == 0xC9 || op == 0xE9 || (op == 0xED && (b1 == 0x45 || b1 == 0x4D)) || ((op == 0xDD || op == 0xFD) && b1 == 0xE9)) break;
            a += l;
        }
    }
    #undef SGM_ADD
    free(todo); free(queued);
    // the start-up clear: LD HL,2000 / LD DE,2001 / LD BC,5FFF / LD (HL),0 / LDIR
    static const uint8_t clr[] = {0x21, 0x00, 0x20, 0x11, 0x01, 0x20, 0x01, 0xFF, 0x5F, 0x36, 0x00, 0xED, 0xB0};
    int clr_at = -1;
    for (size_t i = fix; i + sizeof clr <= fix + fixlen && clr_at < 0; i++) if (!memcmp(&cart[i], clr, sizeof clr)) clr_at = (int)i;
    // the variables: 2000 up to the highest address used; the lowest use from 6000 (CVBasic's own) must be above
    int hi = 0x1FFF, low6 = 0x8000, nimm = 0, ndir = 0;
    for (size_t o = 0; o + 4 <= len; o++) {
        if (!seen[o] || (clr_at >= 0 && (int)o >= clr_at && (int)o < clr_at + 9)) continue;
        int imm, p = sgm_operand(&cart[o], &imm);
        if (!p) continue;
        int v = cart[o + p] | cart[o + p + 1] << 8;
        if (v >= 0x2000 && v < 0x6000 && v > hi && (!imm || sgm_deref(cart, len, o))) hi = v;   // (VRAM addresses are immediates too)
        if (!imm && v >= 0x6000 && v < low6) low6 = v;
    }
    if (hi < 0x2000) { printf(" no variables in 2000-5FFF, left alone"); free(seen); return; }
    if (hi + 1 + 0x4000 > 0x7000 || hi + 1 + 0x4000 > low6) {
        printf("\n    variables 2000-%04X don't fit in the NABU's free RAM (6000-6FFF, below 0x%04X): NOT converted", hi + 1, low6);
        free(seen); return;
    }
    // the SGM test
    cart[test] = 0xC3; cart[test + 1] = ok_to & 0xFF; cart[test + 2] = ok_to >> 8;
    printf("\n    [0x%04X] SGM test skipped (JP 0x%04X)", (uint32_t)(test - fix + 0x8000), ok_to);
    if (clr_at >= 0) {
        cart[clr_at + 2] = 0x60; cart[clr_at + 5] = 0x60; cart[clr_at + 8] = 0x1F;
        printf("\n    [0x%04X] start-up RAM clear: 6000-7FFF (was 2000-7FFF)", (uint32_t)(clr_at - fix + 0x8000));
    } else printf("\n    WARNING: start-up RAM clear (2000-7FFF) not found");
    // move the variables
    for (size_t o = 0; o + 4 <= len; o++) {
        if (!seen[o]) continue;
        int imm, p = sgm_operand(&cart[o], &imm);
        if (!p) continue;
        int v = cart[o + p] | cart[o + p + 1] << 8;
        if (v < 0x2000 || v > hi) continue;
        if (imm && sgm_keep(cart, len, o, v)) continue;
        v += 0x4000; cart[o + p] = v & 0xFF; cart[o + p + 1] = v >> 8;
        if (imm) nimm++; else ndir++;
    }
    printf("\n    variables 2000-%04X -> 6000-%04X: %d addresses and %d pointers moved", hi, hi + 0x4000, ndir, nimm);
    // the AY
    int latch = 0, write = 0, nlat = 0, nwr = 0, nrd = 0, n53 = 0;
    if (gap && gap->next && gap->next + 51 <= gap->end && cart[fix + 0x0C] == 0xC3 && cart[fix + 0x1E] == 0xC3 &&
        !(cart[fix + 0x0D] | cart[fix + 0x0E] | cart[fix + 0x1F] | cart[fix + 0x20])) {
        latch = gap->next; write = latch + 6;
        int reg = write + 44, on = write + 15, off = write + 16;
        const uint8_t h[51] = {0x32, (uint8_t)reg, (uint8_t)(reg >> 8), 0xD3, 0x41, 0xC9,     // latch: LD (reg),A / OUT (41h),A / RET
            0xF5, 0xC5, 0x4F, 0x06, 0x00, 0xED, 0x57, 0xEA, (uint8_t)on, (uint8_t)(on >> 8),   // write: B = 1 if IFF2 (asked twice)
            0xED, 0x57, 0xE2, (uint8_t)off, (uint8_t)(off >> 8), 0x04, 0xF3,
            0x3A, (uint8_t)reg, (uint8_t)(reg >> 8), 0xFE, 0x0E, 0x30, 0x0D,                   // DI / A = reg / 14, 15: skip
            0xD3, 0x41, 0xFE, 0x07, 0x79, 0x20, 0x04, 0xE6, 0x3F, 0xF6, 0x40,                  // select again / 7: port A out, B in
            0xD3, 0x40, 0x05, 0x20, 0x01, 0xFB, 0xC1, 0xF1, 0xC9, 0x00};                       // write / EI if it was on
        memcpy(&gap->stub[gap_off(gap, latch)], h, 51);
        gap->next += 51;
        cart[fix + 0x0D] = latch & 0xFF; cart[fix + 0x0E] = latch >> 8;
        cart[fix + 0x1F] = write & 0xFF; cart[fix + 0x20] = write >> 8;
        for (size_t o = 0; o + 2 <= len; o++) {
            if (!seen[o]) continue;
            uint8_t op = cart[o], b1 = cart[o + 1];
            int c = -1;                                                  // OUT (C),A: C from LD C,n or LD A,n / LD C,A just before
            if (op == 0xED && b1 == 0x79) {
                if (o >= 2 && cart[o - 2] == 0x0E) c = cart[o - 1];                                          // LD C,n
                else if (o >= 4 && cart[o - 4] == 0x0E && cart[o - 2] == 0x3E) c = cart[o - 3];             // LD C,n / LD A,v
                else if (o >= 5 && cart[o - 5] == 0x0E && cart[o - 3] == 0x3A) c = cart[o - 4];             // LD C,n / LD A,(v)
                else if (o >= 3 && cart[o - 3] == 0x3E && cart[o - 1] == 0x4F) c = cart[o - 2];             // LD A,n / LD C,A
                else if (o >= 5 && cart[o - 5] == 0x3E && cart[o - 3] == 0x4F && cart[o - 2] == 0x3E) c = cart[o - 4];   // + LD A,v
                else if (o >= 6 && cart[o - 6] == 0x3E && cart[o - 4] == 0x4F && cart[o - 3] == 0x3A) c = cart[o - 5];   // + LD A,(v)
            }
            if ((op == 0xD3 && b1 == 0x50) || c == 0x50) { cart[o] = 0xCF; cart[o + 1] = 0x00; nlat++; }
            else if ((op == 0xD3 && b1 == 0x51) || c == 0x51) { cart[o] = 0xFF; cart[o + 1] = 0x00; nwr++; }
            else if (op == 0xDB && b1 == 0x52) { cart[o + 1] = 0x40; nrd++; }
            else if ((op == 0xD3 && b1 == 0x53) || c == 0x53) { cart[o] = 0x00; cart[o + 1] = 0x00; n53++; }
        }
        printf("\n    SGM AY -> the NABU's: %d latch (RST 08 -> 0x%04X), %d write (RST 38 -> 0x%04X), %d read, %d OUT (53h) dropped",
               nlat, latch, nwr, write, nrd, n53);
    } else printf("\n    SGM AY: no room or cart vectors 800C/801E in use: NOT converted (no SGM sound)");
    for (size_t o = 0; o + 2 <= len; o++)                                // any left
        if (seen[o] && ((cart[o] == 0xD3 && cart[o + 1] >= 0x50 && cart[o + 1] <= 0x53) || (cart[o] == 0xDB && cart[o + 1] == 0x52)))
            printf("\n    [0x%05X] WARNING: SGM port instruction left", (uint32_t)o);
    free(seen);
}

void process_file(const char* filename, uint8_t* stub_data, size_t stub_len, int skip_patches, int swap_joy, int smart_ports, int swapfire, int upbutton2) {
    FILE* f = fopen(filename, "rb");
    if (!f) return;
    fseek(f, 0, SEEK_END); size_t rom_len = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t* rom = NULL, *cart = NULL;
    int nb = 0;
    if (rom_len > MAX_ROM_SIZE) {                                   // a megacart: see megacart_banks
        nb = (int)(rom_len / 0x4000);
        cart = (uint8_t*)malloc(rom_len);
        fread(cart, 1, rom_len, f); fclose(f);
        const uint8_t* hd = cart + (size_t)(nb - 1) * 0x4000;
        if (rom_len % 0x4000 || (nb != 4 && nb != 8 && nb != 16) ||
            !((hd[0] == 0x55 && hd[1] == 0xAA) || (hd[0] == 0xAA && hd[1] == 0x55))) {
            printf("Processing: %-32s OVER 32KB, not a megacart, SKIPPED\n", filename); free(cart); return;
        }
        rom = (uint8_t*)malloc(MAX_ROM_SIZE);                        // the fixed bank at 8000, bank NB-2 at C000
        memcpy(rom, hd, 0x4000); memcpy(rom + 0x4000, hd - 0x4000, 0x4000);
        rom_len = MAX_ROM_SIZE;
    } else {
        rom = (uint8_t*)calloc(rom_len > MAX_ROM_SIZE ? rom_len : MAX_ROM_SIZE, 1);   // (room for amy_tts after the ROM)
        fread(rom, 1, rom_len, f); fclose(f);
    }
    uint16_t crc = calculate_crc16(rom, rom_len);
    printf("Processing: %-32s (CRC: 0x%04X)", filename, crc);
    size_t stub_off = stub_len - MAX_ROM_SIZE;
    uint8_t* stub = (uint8_t*)malloc(stub_off);                    // per-ROM copy: RST dispatchers go in its gap
    memcpy(stub, stub_data, stub_off);
    Gap gap;
    int have_gap = stub_info(&gap, stub, stub_off);
    if (!have_gap) printf("\n  WARNING: loader stub has no info block (old stub?): no RST dispatchers, NMI wrapper or options");
    keymap_options(stub, stub_off, swapfire, upbutton2);
    if (!skip_patches) {                                            // CVBasic SGM games: before everything else
        if (nb) {
            cvbasic_sgm(cart, (size_t)nb * 0x4000, nb, have_gap ? &gap : NULL);
            memcpy(rom, cart + (size_t)(nb - 1) * 0x4000, 0x4000); memcpy(rom + 0x4000, cart + (size_t)(nb - 2) * 0x4000, 0x4000);
        } else cvbasic_sgm(rom, rom_len, 0, have_gap ? &gap : NULL);
    }
    cur_known = NULL;
    for (size_t k = 0; k < sizeof known_data / sizeof known_data[0]; k++)
        if (known_data[k].crc == crc) cur_known = known_data[k].offsets;
    const MegaCode* mc = NULL;
    int nxbanks_done = 0;                                           // code banks converted into the cart copy
    uint8_t* save_xb = xbanks; int save_nxb = nxbanks;           // -xbanks is for 32KB images; a megacart sets its own
    int nb2_code = 0;
    if (nb) {
        for (size_t k = 0; k < sizeof mega_code / sizeof mega_code[0]; k++) if (mega_code[k].crc == crc) mc = &mega_code[k];
        // NAME.COL beside NAME.NAB, with code banks: this converter's output (its banks already converted),
        // e.g. picked up again by a *.col wildcard
        char nab[1100]; size_t fl = strlen(filename);
        if (mc && fl > 4 && fl < 1000 && !_stricmp(filename + fl - 4, ".col")) {
            memcpy(nab, filename, fl - 4); strcpy(nab + fl - 4, ".NAB");
            FILE* nf = fopen(nab, "rb");
            if (nf) {
                fclose(nf);
                printf("\n  A converted megacart (%s beside it): its code banks are converted already, SKIPPED\n\n", nab);
                free(stub); free(rom); free(cart); return;
            }
        }
        xbanks = NULL; nxbanks = 0;
        if (mc) {
            printf("\n  Megacart code banks (%s):", mc->name);
            xbanks = malloc(16 * 0x4000);
            for (const int* b = mc->banks; *b >= 0; b++) {
                printf(" %d", *b);
                if (*b == nb - 2) { nb2_code = 1; continue; }
                xbank_ids[nxbanks] = *b;
                memcpy(xbanks + (size_t)nxbanks++ * 0x4000, cart + (size_t)*b * 0x4000, 0x4000);
            }
            xbank_mega = 1; xbank_crc = crc;
        }
    }
    if (!skip_patches && !apply_external_patches(rom, rom_len, crc)) {
        amy_rom_len = 0;
        apply_auto_patches(rom, rom_len, swap_joy, smart_ports, have_gap ? &gap : NULL);
        port_vars(rom, rom_len, nb ? cart : rom, nb ? (size_t)nb * 0x4000 : rom_len);
        if (amy_rom_len > rom_len) rom_len = amy_rom_len;          // the text to speech after the ROM
    }
    if (nb && mc && mc->nmi_stack && !skip_patches) nmi_own_stack(rom, have_gap ? &gap : NULL);
    if (nb && mc) {                                                 // the converted code banks into NAME.COL
        if (xbanks_out) { for (int b = 0; b < nxbanks; b++) memcpy(cart + (size_t)xbank_ids[b] * 0x4000, xbanks_out + (size_t)b * 0x4000, 0x4000); nxbanks_done = nxbanks; }
        else if (nxbanks) printf("\n  WARNING: code banks not converted (-nopatch or known-title patches)");
        free(xbanks); free(xbanks_out); xbanks_out = NULL;
        xbank_mega = 0;
    }
    if (nb) { xbanks = save_xb; nxbanks = save_nxb; }
    if (nb) {
        printf("\n  Megacart: %d banks of 16KB (NABU with the RomWBW card, CVLOAD.COM)", nb);
        if (!megacart_banks(rom, cart + (size_t)(nb - 2) * 0x4000, nb, have_gap ? &gap : NULL, nb2_code)) {
            printf("\n  Megacart: bank switching not recognised, SKIPPED\n\n");
            free(stub); free(rom); free(cart); return;
        }
        // banks with many OUT / IN on the Coleco ports: their own code likely does I/O, which this doesn't
        // convert (megaprep.py --convert-banks does)
        for (int b = 0; b < nb - 1; b++) {
            int listed = 0;
            for (const int* x = mc ? mc->banks : NULL; x && *x >= 0; x++) listed |= *x == b;
            if (listed) continue;
            const uint8_t* d = cart + (size_t)b * 0x4000;
            int io = 0;
            for (int i = 0; i + 1 < 0x4000; i++)
                if ((d[i] == 0xD3 || d[i] == 0xDB) && (d[i + 1] == 0xBE || d[i + 1] == 0xBF || d[i + 1] == 0xFC || d[i + 1] == 0xFF ||
                                                       d[i + 1] == 0xC0 || d[i + 1] == 0x80 || d[i + 1] == 0xE0 || d[i + 1] == 0xF0)) io++;
            if (io >= 8) printf("\n  WARNING: bank %d has %d port instructions: if its code does I/O, use megaprep.py --convert-banks", b, io);
        }
    }
    if (have_gap) stub[gap_off(&gap, gap.options)] |= gap.option_bits;     // loader options (port swap)

    char base[1024]; strncpy(base, filename, 1023);
    char* dot = strrchr(base, '.'); if (dot) *dot = '\0';
    size_t pay_len = stub_off + rom_len;
    uint8_t* nabu_out = (uint8_t*)malloc(pay_len);
    if (nabu_out && nb) {                                            // megacart: NAME.NAB + NAME.COL (8.3 names)
        memcpy(nabu_out, stub, stub_off);
        memcpy(nabu_out + stub_off, rom, rom_len);
        char name[9];
        const char* bn = base;
        for (const char* p = base; *p; p++) if (*p == '\\' || *p == '/') bn = p + 1;
        mega_name(bn, name);
        char out[1100];
        int same_file = 0;                                           // NAME.COL is the ROM itself (Prince.col -> PRINCE.COL)
        snprintf(out, sizeof out, "%.*s%s.COL", (int)(bn - base), base, name);
        if (!_stricmp(out, filename)) {
            if (nxbanks_done) {                                      // its banks were converted: don't overwrite the ROM
                size_t nl = strlen(name);
                if (nl < 8) name[nl++] = '_'; else name[7] = '_';
                name[nl] = 0;
            } else same_file = 1;                                    // the same bytes: leave the ROM as it is
        }
        snprintf(out, sizeof out, "%.*s%s.NAB", (int)(bn - base), base, name);
        FILE* nf = fopen(out, "wb");
        if (nf) { fwrite(nabu_out, 1, pay_len, nf); fclose(nf); printf("\n  [+] Created: %s", out); }
        snprintf(out, sizeof out, "%.*s%s.COL", (int)(bn - base), base, name);
        if (same_file) printf("\n  [=] %s is the ROM itself (unchanged)", out);
        else {
            nf = fopen(out, "wb");
            if (nf) { fwrite(cart, 1, (size_t)nb * 0x4000, nf); fclose(nf); printf("\n  [+] Created: %s", out); }
        }
        printf("\n  Copy both to the RomWBW disk and run: CVLOAD %s\n\n", name);
        free(nabu_out); nabu_out = NULL;
    }
    if (nabu_out) {
        memcpy(nabu_out, stub, stub_off);
        memcpy(nabu_out + stub_off, rom, rom_len);
        char out[1100]; sprintf(out, "%s.nabu", base);
        FILE* nf = fopen(out, "wb");
        if (nf) { fwrite(nabu_out, 1, pay_len, nf); fclose(nf); printf("\n  [+] Created: %s", out); }
        
        uint8_t* com_out = (uint8_t*)malloc(STUB_SIZE + pay_len);
        if (com_out) {
            uint16_t se = 0x0100 + STUB_SIZE + (uint16_t)pay_len - 1;
            uint16_t de = 0x140D + (uint16_t)pay_len - 1;
            uint8_t cs[STUB_SIZE] = {0xF3, 0x01, pay_len&0xFF, pay_len>>8, 0x21, se&0xFF, se>>8, 0x11, de&0xFF, de>>8, 0xED, 0xB8, 0xC3, 0x10, 0x14};
            memcpy(com_out, cs, STUB_SIZE); memcpy(com_out + STUB_SIZE, nabu_out, pay_len);
            sprintf(out, "%s.com", base);
            FILE* cf = fopen(out, "wb");
            if (cf) { fwrite(com_out, 1, STUB_SIZE + pay_len, cf); fclose(cf); printf("\n  [+] Created: %s", out); }
            free(com_out);
        }
        if (xbanks_out) {                                            // -xbanks: the converted extra banks
            sprintf(out, "%s.xb", base);
            FILE* xf = fopen(out, "wb");
            if (xf) { fwrite(xbanks_out, 1, (size_t)nxbanks * 0x4000, xf); fclose(xf); printf("\n  [+] Created: %s", out); }
        }
        printf("\n\n"); free(nabu_out);
    }
    free(stub);
    free(rom);
    free(cart);
}

int main(int argc, char* argv[]) {
    printf("coleco2nabu v0.6 by GTAMP (c) 2026\n");
    printf("based on Coleco Loader by Brian Johnson\n");
    int skip = 0, swap = 2, f_count = 0, smart = 1, swapfire = 0, upbutton2 = 0;   // swap: 2 = auto
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-nopatch")) skip = 1;
        else if (!strcmp(argv[i], "-swapfire")) swapfire = 1;
        else if (!strcmp(argv[i], "-upbutton2")) upbutton2 = 1;
        else if (!strcmp(argv[i], "-swapjoy")) swap = 1;
        else if (!strcmp(argv[i], "-noswapjoy")) swap = 0;
        else if (!strcmp(argv[i], "-nosmart")) smart = 0;
        else if (!strcmp(argv[i], "-2")) ;   // old 2-player stub switch: the one stub does both now
        else if (!strcmp(argv[i], "-speech") && i + 1 < argc) {     // Amy Studio speech texts: "CLIP text" lines (hex clip address)
            FILE* sf = fopen(argv[++i], "r");
            if (!sf) { printf("cannot open %s\n", argv[i]); return 1; }
            char line[512];
            while (fgets(line, sizeof line, sf) && amy_nspeech < 256) {
                char* e = line + strlen(line);
                while (e > line && (e[-1] == '\n' || e[-1] == '\r' || e[-1] == ' ' || e[-1] == '\t')) *--e = 0;
                char* t;
                long clip = strtol(line, &t, 16);
                if (t == line || clip < 0x8000 || clip > 0xFFFF || line[0] == '#') continue;
                while (*t == ' ' || *t == '\t') t++;
                if (!*t) continue;
                int k = 0;
                while (k < amy_nspeech && amy_speech_clip[k] != clip) k++;
                if (k == amy_nspeech) amy_nspeech++;
                amy_speech_clip[k] = (int)clip;
                snprintf(amy_speech_text[k], sizeof amy_speech_text[k], "%.255s", t);
            }
            fclose(sf);
            for (int a = 1; a < amy_nspeech; a++)                      // sorted by clip
                for (int b = a; b > 0 && amy_speech_clip[b - 1] > amy_speech_clip[b]; b--) {
                    int c = amy_speech_clip[b]; amy_speech_clip[b] = amy_speech_clip[b - 1]; amy_speech_clip[b - 1] = c;
                    char tmp[256]; memcpy(tmp, amy_speech_text[b], 256); memcpy(amy_speech_text[b], amy_speech_text[b - 1], 256); memcpy(amy_speech_text[b - 1], tmp, 256);
                }
        }
        else if (!strcmp(argv[i], "-xbanks") && i + 1 < argc) {
            FILE* xf = fopen(argv[++i], "rb");
            if (!xf) { printf("cannot open %s\n", argv[i]); return 1; }
            fseek(xf, 0, SEEK_END); long xl = ftell(xf); fseek(xf, 0, SEEK_SET);
            xbanks = malloc(xl); fread(xbanks, 1, xl, xf); fclose(xf);
            nxbanks = (int)(xl / 0x4000);
        }
        else f_count++;
    }
    if (f_count == 0) { printf("\nUsage: coleco2nabu <roms> [-nopatch] [-swapjoy|-noswapjoy] [-swapfire] [-upbutton2] [-nosmart] [-xbanks banks.bin] [-speech texts.txt]\n"); return 1; }

    FILE* pf = fopen("patches.z80", "rb");       // known titles' patches (optional)
    if (pf) {
        fseek(pf, 0, SEEK_END); long pl = ftell(pf); fseek(pf, 0, SEEK_SET);
        patches_text = calloc(pl + 1, 1); fread(patches_text, 1, pl, pf); fclose(pf);
    } else printf("Note: patches.z80 not found, known-title patches are not applied\n");

    FILE* ts = fopen("coleco2nabu.001", "rb");   // loader stub, built from loader/ (build.py)
    if (!ts) { ts = fopen("coleco2nabu.bin", "rb"); if (!ts) return 1; }
    fseek(ts, 0, SEEK_END); size_t sl = ftell(ts); fseek(ts, 0, SEEK_SET);
    uint8_t* sd = (uint8_t*)malloc(sl); fread(sd, 1, sl, ts); fclose(ts);

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-xbanks") || !strcmp(argv[i], "-speech")) { i++; continue; }
        if (argv[i][0] == '-') continue;
        char* pat = argv[i]; struct _finddata_t cf; intptr_t h;
        char dir[512] = ""; 
        const char *ls = strrchr(pat, '\\'), *lf = strrchr(pat, '/'), *sep = (ls > lf) ? ls : lf;
        if (sep) { size_t len = (sep - pat) + 1; strncpy(dir, pat, len); dir[len] = '\0'; }
        if ((h = _findfirst(pat, &cf)) != -1L) {
            do { if (!(cf.attrib & _A_SUBDIR)) { 
                char full[2048]; snprintf(full, 2048, "%s%s", dir, cf.name); 
                process_file(full, sd, sl, skip, swap, smart, swapfire, upbutton2);
            } } while (_findnext(h, &cf) == 0);
            _findclose(h);
        }
    }
    free(sd); return 0;
}